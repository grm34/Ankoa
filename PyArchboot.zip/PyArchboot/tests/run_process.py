# -*- coding: utf-8 -*-

import shlex
from subprocess import PIPE, STDOUT, Popen


def run_command(cmd):
    process = Popen(shlex.split(cmd), stdin=PIPE, stdout=PIPE)
    while True:
        output = process.stdout.readline()
        if output:
            print(output.decode('utf-8').strip())
        else:
            break
    command_output = process.poll()
    return command_output


print('test is running...')
cmd = 'yay --noconfirm -S flashplugin'
run_command(cmd)
print('test done.')
