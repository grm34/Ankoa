# -*- coding: utf-8 -*-

import os
import re
import shlex
from shutil import copy2, copyfile, copytree, move, rmtree
from subprocess import PIPE, STDOUT, Popen, check_output


def run_command(cmd):
    process = Popen(shlex.split(cmd), stdin=PIPE, stdout=PIPE)
    while True:
        output = process.stdout.readline()
        if output:
            print(output.decode('utf-8').strip())
        else:
            break
    command_output = process.poll()
    return command_output


username = 'luna'
aur_helper = 'Pamac-aur'

# Set root privilege without password
with open('/etc/sudoers', 'r') as sudoers:
    sudo_list = list(sudoers)

sudo = []
for line in sudo_list:
    line = re.sub(' +', ' ', line)
    line = line.replace(
        '{user} ALL=(ALL) ALL'.format(user=username),
        '{user} ALL=(ALL) NOPASSWD: ALL'.format(user=username))
    sudo.append(line)

with open('/etc/sudoers', 'w+') as file:
    for line in sudo:
        file.write(line)

# Clone the AUR Helper repository
cmd = 'sudo -u {user} git clone \
https://aur.archlinux.org/{aur}.git /home/{user}/{aur}'.format(
    user=username, aur=aur_helper.lower())

run_command(cmd)

# Install the AUR Helper
os.chdir('/home/{user}/{aur}/'.format(user=username, aur=aur_helper.lower()))
cmd = 'sudo -u {user} makepkg --noconfirm --needed -sic'.format(user=username)

run_command(cmd)

# Restore root privilege access
with open('/etc/sudoers', 'r') as sudoers:
    sudo_list = list(sudoers)

sudo = []
for line in sudo_list:
    line = re.sub(' +', ' ', line)
    line = line.replace(
        '{user} ALL=(ALL) NOPASSWD: ALL'.format(user=username),
        '{user} ALL=(ALL) ALL'.format(user=username))
    sudo.append(line)

with open('/etc/sudoers', 'w+') as file:
    for line in sudo:
        file.write(line)

# Remove AUR Helper repository folder
rmtree('/home/{user}/{aur}'
       .format(user=username, aur=aur_helper.lower()))
