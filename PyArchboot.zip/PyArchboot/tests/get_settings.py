# -*- coding: utf-8 -*-

import sys
from subprocess import CalledProcessError, check_output


def get_system_settings(cmd, error):

    try:
        cmd = check_output(cmd, shell=True, encoding='utf-8')
        return cmd

    except CalledProcessError:
        eval(error)


drive_list = get_system_settings(
    'lsblk -I 8 -d -p -o NAME,SIZE,MODEL | grep -v NAME',
    "print('no drive detected !') + sys.exit(1)")
drive_list = list(filter(None, drive_list.split('\n')))
print(drive_list)
