File|blank|comment|code
:-------|-------:|-------:|-------:
modules/manager.py|285|205|611
modules/installer.py|182|72|365
modules/partitioner.py|111|50|242
PyArchboot.py|55|29|117
--------|--------|--------|--------
SUM:|633|356|1335
