File|blank|comment|code
:-------|-------:|-------:|-------:
modules/manager.py|347|457|611
modules/installer.py|189|93|365
modules/partitioner.py|121|75|242
PyArchboot.py|60|64|118
--------|--------|--------|--------
SUM:|717|689|1336
