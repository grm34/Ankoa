File|blank|comment|code
:-------|-------:|-------:|-------:
modules/manager.py|247|172|615
modules/installer.py|183|72|367
modules/partitioner.py|111|50|233
PyArchboot.py|55|29|116
--------|--------|--------|--------
SUM:|596|323|1331
