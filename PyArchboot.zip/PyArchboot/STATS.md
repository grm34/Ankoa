File|blank|comment|code
:-------|-------:|-------:|-------:
modules/manager.py|173|172|606
modules/installer.py|102|71|336
modules/partitioner.py|55|50|223
PyArchboot.py|32|28|109
--------|--------|--------|--------
SUM:|362|321|1274
