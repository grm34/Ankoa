File|blank|comment|code
:-------|-------:|-------:|-------:
PyArchboot/modules/manager.py|171|173|610
PyArchboot/modules/installer.py|95|62|332
PyArchboot/modules/partitioner.py|52|48|219
PyArchboot/PyArchboot.py|30|33|104
--------|--------|--------|--------
SUM:|348|316|1265
