File|blank|comment|code
:-------|-------:|-------:|-------:
modules/manager.py|169|172|715
modules/installer.py|95|62|428
modules/partitioner.py|52|48|262
PyArchboot.py|22|26|54
--------|--------|--------|--------
SUM:|338|308|1459
