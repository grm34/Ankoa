File|blank|comment|code
:-------|-------:|-------:|-------:
modules/manager.py|172|169|606
modules/installer.py|98|64|336
modules/partitioner.py|55|50|223
PyArchboot.py|32|28|109
--------|--------|--------|--------
SUM:|357|311|1274
