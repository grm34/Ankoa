# -*- coding: utf-8 -*-

'''
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
'''

import os
import sys
import time
import json
import shlex
import argparse
import gettext
import logging
import coloredlogs
import inquirer

from inquirer.themes import load_theme_from_dict
from termcolor import (cprint, colored)
from requests import (get, ConnectionError)
from subprocess import (check_output,
                        Popen, PIPE, TimeoutExpired, CalledProcessError)
from shlex import quote


# Load app settings
with open('{path}/json/app.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as app_settings:
    app = json.load(app_settings)


# Load inquirer theme
with open('{path}/json/theme.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as inquirer_theme:
    theme = json.load(inquirer_theme)


def PyArchboot_help():

    parser = argparse.ArgumentParser(
        prog=colored(app['name'], 'green', attrs=['bold']),
        description=colored(app['title'], 'white', attrs=['bold']),
        usage=colored(app['usage'], 'grey', 'on_cyan'),
        epilog=colored('More information at {url}'.format(
                url=colored(app['url'], 'cyan', attrs=['bold']))))

    parser.add_argument('-l', '--lang', nargs=1,
                        choices=['de', 'en', 'es', 'fr', 'ru'],
                        help='installer language selection')

    parser.add_argument('-k', '--key', nargs=1,
                        help='keyboard layout selection')

    parser.add_argument('-f', '--file', nargs=1,
                        help='install additional packages from file')

    args = parser.parse_args()
    return args


def PyArchboot_logging():

    # Update the system clock
    try:
        check_output('timedatectl set-ntp true', shell=True, timeout=1)

    except TimeoutExpired:
        pass

    # Set logging handlers
    logging.basicConfig(filename='{path}/logs/{appname}.log'.format(
                        path=os.getcwd(), appname=app['name']),
                        level=logging.DEBUG, filemode='w',
                        format='%(asctime)s [%(levelname)s] \
%(pathname)s:%(lineno)d [%(funcName)s] %(message)s')

    console = logging.getLogger()

    coloredlogs.install(
        level='INFO', logger=console, datefmt='%H:%M:%S',
        fmt='[%(asctime)s] %(levelname)s > %(message)s',
        level_styles={'critical': {'bold': True, 'color': 'red'},
                      'debug': {'color': 'green'},
                      'error': {'color': 'red'},
                      'info': {'color': 'cyan'},
                      'warning': {'color': 'yellow', 'bold': True}},
        field_styles={'levelname': {'bold': True, 'color': 'green'},
                      'asctime': {'color': 'yellow'}})

    return logging


def PyArchboot_options(args):

    # Get IP Adress Data
    try:
        ipinfo = get('https://ipinfo.io?token=26d03faada92e8').json()
        app['ipinfo'] = ipinfo

    except ConnectionError:
        logging.error('no internet connection !')
        sys.exit(1)

    # Language (-l, --lang)
    if args.lang:
        app['lang'] = args.lang[0].strip()

    else:
        app['lang'] = ipinfo['country'].lower()

    # Keyboard layout (-k, --key)
    if args.key:
        try:
            check_output('loadkeys {key}'.format(key=quote(args.key)),
                         shell=True, timeout=1)

        except CalledProcessError:
            logging.error('invalid keyboard layout !')
            sys.exit(1)

    # Update app settings
    with open('{path}/json/app.json'.format(path=os.getcwd()), 'w',
              encoding='utf-8') as app_settings:
        json.dump(app, app_settings, ensure_ascii=False, indent=4)


def PyArchboot():

    # Display app description
    for key in range(4):
        cprint(app['ascii{key}'.format(key=key)], 'blue', attrs=['bold'])

    cprint(app['title'], 'red', attrs=['bold'])

    for key in range(7):
        cprint(app['description{key}'.format(key=key)], 'white')

    cprint(app['separator'], 'blue', attrs=['bold'])

    # Set the intaller language
    language = gettext.translation('PyArchboot', localedir='locales',
                                   languages=['{lang}'
                                              .format(lang=app['lang'])])
    trad = language.gettext

    # Run module: manager
    logging.info(trad('use arrow keys to select an option'))
    logging.warning(trad('all data on the selected drive will be lost !'))
    from modules import manager

    # Run module: partitioner
    from modules import partitioner

    # Run module: installer
    from modules import installer
    logging.info(trad('installation successfull'))

    # Umount the partitions and reboot the system
    question = [inquirer.Confirm(
        'reboot', message=trad('Do you wish to reboot your computer now'),
        default=True)]

    confirm = inquirer.prompt(question, theme=load_theme_from_dict(theme))
    if confirm['reboot'] is True:

        for second in range(5, 0, -1):
            message = 'System will reboot in {second}s'.format(
                second=str(second))

            cprint(message, 'green', attrs=['bold'], end='\r')
            time.sleep(1)

        Popen(shlex.split('umount -R /mnt && reboot'),
              stdin=PIPE, stdout=PIPE)

    else:
        sys.exit(0)


if __name__ == '__main__':
    args = PyArchboot_help()
    logging = PyArchboot_logging()
    PyArchboot_options(args)
    PyArchboot()


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
