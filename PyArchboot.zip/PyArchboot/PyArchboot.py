# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

import os
import sys
import time
import inquirer
import logging
import coloredlogs

from termcolor import (cprint, colored)
from requests import (get, ConnectionError)
from subprocess import (Popen, PIPE)

import gettext
language = gettext.translation('PyArchboot', 'locales')
trad = language.gettext

import argparse
from app.information import app
parser = argparse.ArgumentParser(
    prog=colored(app['name'], 'green', attrs=['bold']),
    description=cprint(app['ascii'], 'blue', attrs=['bold']),
    usage=colored(app['usage'], 'green', attrs=['reverse']),
    epilog=cprint(app['title'], 'red', attrs=['bold'])
)
parser.add_argument('-l', '--lang', nargs=1, help='language selection')
parser.add_argument('-k', '--key', nargs=1, help='keyboard layout selection')
parser.add_argument(
    '-f', '--file', nargs=1, help='install additional packages from file'
)
parser.parse_args()


def PyArchboot():

    # Update system clock
    Popen(['timedatectl', 'set-ntp', 'true'], stdin=PIPE, stdout=PIPE)

    # Set up logging
    logging.basicConfig(
        filename='{path}/temp/{appname}.log'.format(
            path=os.getcwd(), appname=app['name']),
        level=logging.DEBUG,
        format='%(asctime)s [%(levelname)s] %(pathname)s:%(lineno)d \
[%(funcName)s] %(message)s'
    )
    console = logging.getLogger()
    coloredlogs.install(
        level='INFO',
        logger=console,
        datefmt='%H:%M:%S',
        fmt='[%(asctime)s] %(levelname)s -> %(message)s',
        level_styles={
            'critical': {'bold': True, 'color': 'red'},
            'debug': {'color': 'green'},
            'error': {'color': 'red'},
            'info': {'color': 'cyan'},
            'warning': {'color': 'yellow', 'bold': True}
        },
        field_styles={
            'levelname': {'bold': True, 'color': 'green'},
            'asctime': {'color': 'yellow'}
        }
    )

    # Display description
    cprint(app['description'], 'white')
    cprint(
        '{separator}\n'.format(separator=app['separator']),
        'blue', attrs=['bold']
    )

    # Ensure user is connected
    try:
        logging.info(trad('internet connection check'))
        get('http://archlinux.org', timeout=0.5)
    except ConnectionError:
        logging.error(trad('you are not connected to internet !'))
        sys.exit(1)

    # Run module: manager
    logging.warning(trad('all data on the selected drive will be lost !'))
    from modules import manager

    # Run module: partitioner
    from modules import partitioner

    # Run module: installer
    from modules import installer

    # Reboot
    logging.info(trad('installation successfull'))
    confirm = inquirer.confirm(
        trad('Do you wish to reboot your computer now'), default=True
    )
    if confirm is True:
        for second in range(5, 0, -1):
            message = 'System will reboot in {second}s'.format(
                second=str(second)
            )
            cprint(message, 'green', attrs=['bold'], end='\r')
            time.sleep(1)
        Popen(
            ['umount', '-R', '/mnt', '&&', 'reboot'], stdin=PIPE, stdout=PIPE
        )
    else:
        sys.exit(0)


if __name__ == '__main__':
    PyArchboot()


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
