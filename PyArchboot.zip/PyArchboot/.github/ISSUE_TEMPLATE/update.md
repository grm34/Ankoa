---
name: 'Update'
about: 'Require an update of PyArchboot'
title: ''
labels: '🕒 update required'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->
