---
name: 'Language request'
about: 'Suggest new language for PyArchboot'
title: ''
labels: '🇫🇷 language request'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->
