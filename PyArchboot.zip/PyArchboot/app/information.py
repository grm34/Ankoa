# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

app = {
    'name': 'PyArchboot',
    'version': 'v0.0.1',
    'author': 'grm34',
    'license': 'Apache License 2.0',

    'ascii': '''
 ┌─┐┬ ┬┌─┐┬─┐┌─┐┬ ┬┌┐ ┌─┐┌─┐┌┬┐  ┌─┐┬─┐┌─┐┬ ┬  ┬┌┐┌┌─┐┌┬┐┌─┐┬  ┬  ┌─┐┬─┐
 ├─┘└┬┘├─┤├┬┘│  ├─┤├┴┐│ ││ │ │   ├─┤├┬┘│  ├─┤  ││││└─┐ │ ├─┤│  │  ├┤ ├┬┘
 ┴   ┴ ┴ ┴┴└─└─┘┴ ┴└─┘└─┘└─┘ ┴   ┴ ┴┴└─└─┘┴ ┴  ┴┘└┘└─┘ ┴ ┴ ┴┴─┘┴─┘└─┘┴└─''',

    'title': '''\
   Python Arch Linux Installer v0.0.1 © Script made with love by grm34''',

    'description': '''
     Arch Linux is a light and fast distribution whose concept is to
     remain as simple as possible.  In the same purpose and in order
     to give free choice to the user, this script performs a minimal
     installation, and only the required packages will be installed.
     According to desired configuration and in order to get complete
     support additional packages may be required. __Copyright 2020__''',

    'separator': '''\
     ---------------------------------------------------------------'''
}

# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
