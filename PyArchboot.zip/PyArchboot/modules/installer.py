# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

import os
import re
import json
import logging

from shutil import (copy2, copyfile, copytree, move, rmtree)
from subprocess import (Popen, PIPE, check_output, CalledProcessError)

import gettext
language = gettext.translation('PyArchboot', 'locales')
trad = language.gettext


# Load user settings
with open(
    '{path}/temp/settings.json'.format(path=os.getcwd()),
    'r', encoding='utf-8'
) as settings:
    user = json.load(settings)


# Load archlinux packages
with open(
    '{path}/packages/archlinux.json'.format(path=os.getcwd()),
    'r', encoding='utf-8'
) as archlinux:
    packages = json.load(archlinux)


""" Install Arch Linux base system
    ______________________________________________________________________ """

# Update mirrorlist
if user['mirrorlist'] is not None:
    logging.info(trad('update mirrorlist'))
    with open('/etc/pacman.d/mirrorlist', 'w+') as mirrorlist:
        mirrorlist.write('{mirrorlist}'.format(mirrorlist=user['mirrorlist']))


# Install base system
logging.info(trad('install Arch Linux base system'))

packages['arch'].append(user['kernel'])
if user['firmware']['driver'] is not None:
    packages['arch'].append(packages['firmware'])
if user['aur_helper'] is True:
    packages['arch'].append(packages['devel'])

cmd = Popen([
    'yes', '|', 'pacstrap', '/mnt', packages['arch']
], stdin=PIPE, stdout=PIPE)


# Create FSTAB
logging.info(trad('create file system table'))

cmd = Popen([
    'genfstab', '-U', '-p', '/mnt', '>>' '/mnt/etc/fstab'
], stdin=PIPE, stdout=PIPE)


# Set timezone
logging.info(
    trad('set timezone [{timezone}]').format(timezone=user['timezone'])
)
cmd = Popen([
    'ln', '-sfv',
    '/usr/share/zoneinfo/{timezone}'.format(timezone=user['timezone']),
    '/mnt/etc/localtime'
], stdin=PIPE, stdout=PIPE)

cmd = Popen(['hwclock', '--systohc'], stdin=PIPE, stdout=PIPE)


# Set locale
logging.info(trad('set locale [{locale}]').format(locale=user['language']))

with open('/mnt/etc/locale.gen', 'a') as locale:
    locale.write('{language}.UTF-8 UTF-8\n'.format(language=user['language']))

cmd = Popen(['arch-chroot', '/mnt', 'locale-gen'], stdin=PIPE, stdout=PIPE)
cmd = Popen([
    'arch-chroot', '/mnt', 'export LANG={language}.UTF-8'
    .format(language=user['language'])
], stdin=PIPE, stdout=PIPE)
with open('/mnt/etc/locale.conf', 'w+') as locale:
    locale.write('LANG={language}.UTF-8\n'.format(language=user['language']))


# Set virtual console
logging.info(
    trad('set virtual console [{keymap}]').format(keymap=user['keymap'])
)
with open('/mnt/etc/vconsole.conf', 'w+') as vconsole:
    vconsole.write('KEYMAP={keymap}\n'.format(keymap=user['keymap']))


# Set hostname
logging.info(
    trad('set hostname [{hostname}]').format(hostname=user['hostname'])
)
with open('/mnt/etc/hostname', 'w+') as hostname:
    hostname.write('{hostname}\n'.format(user['hostname']))


# Set root password
logging.info(trad('set root password'))

cmd_args1 = Popen([
    'echo', 'root:{passwd}'.format(passwd=user['rootpasswd'])
], stdout=PIPE)
cmd_args2 = Popen([
    'arch-chroot', '/mnt', 'chpasswd', '-e'
], stdin=cmd_args1.stdout, stdout=PIPE)
cmd = cmd_args2.communicate()[0]


# Create user
logging.info(trad('create user {user}').format(user=user['username']))

cmd = Popen([
    'arch-chroot', '/mnt', 'useradd', '-g', 'users', '-m', '-s', '/bin/bash',
    '{user}'.format(user=user['username'])
], stdin=PIPE, stdout=PIPE)


# Set user password
logging.info(
    trad('set password for user {user}').format(user=user['username'])
)
cmd_args1 = Popen([
    'echo', '{user}:{passwd}'
    .format(user=user['username'], passwd=user['userpasswd'])
], stdout=PIPE)
cmd_args2 = Popen([
    'arch-chroot', '/mnt', 'chpasswd', '-e'
], stdin=cmd_args1.stdout, stdout=PIPE)
cmd = cmd_args2.communicate()[0]


# Install network
logging.info(trad('install network'))
cmd = Popen([
    'arch-chroot', '/mnt', 'pacman', '--noconfirm', '--needed', '-S',
    packages['network']
], stdin=PIPE, stdout=PIPE)


# Install bootloader
if user['firmware'] == 'bios':
    if user['ntfs'] is True:
        packages['grub']['packages'] = \
            '{packages} {extras}'.format(
                packages=packages['grub']['packages'],
                extras=packages['grub']['extras']
            )
    logging.info(trad('install grub bootloader'))

    cmd = Popen([
        'arch-chroot', '/mnt', 'pacman', '--noconfirm', '--needed', '-S',
        packages['grub']['packages']
    ], stdin=PIPE, stdout=PIPE)


# Install optional packages
for choice, name in zip(
    [
        user['cpu']['microcode'], user['drive']['lvm'], user['ntfs'],
        user['gpu']['driver'], user['gpu']['hardvideo'],
        user['desktop_environment']['requirements'],
        user['desktop_environment']['packages'],
        user['display_manager']['packages']
    ], [
        'microcode updates', 'lvm support', 'ntfs support',
        'GPU driver', 'hardware video acceleration', 'X window system',
        '{desktop}'.format(desktop=user['desktop_environment']['name']),
        '{display}'.format(display=user['display_manager']['name'])
    ]
):
    if (choice is not None) or (choice is not False):
        logging.info(trad('install {name}').format(name=name))

        cmd = Popen([
            'arch-chroot', '/mnt', 'pacman', '--noconfirm', '--needed', '-S',
            choice
        ], stdin=PIPE, stdout=PIPE)


""" Configure bootloader
    ______________________________________________________________________ """

# Set systemd-boot (UEFI)
if (user['firmware']['type'] == 'uefi') and \
        (user['firmware']['version'] == 'x64'):
    logging.info(trad('configure bootloader [systemd-boot]'))

    # Update HOOKS
    with open('/mnt/etc/mkinitcpio.conf', 'r') as mkinitcpio:
        mkinitcpio_list = list(mkinitcpio)

    move(
        '/mnt/etc/mkinitcpio.conf', '/mnt/etc/mkinitcpio.backup',
        copy_function=copy2
    )

    mkinitcpio = []
    for line in mkinitcpio_list:
        line = re.sub(' +', ' ', line)
        if line.startswith('HOOKS=('):
            for key in [' keyboard', ' keymap', ' lvm2', ' encrypt']:
                line = line.replace(key, '')
            line = line.replace(
                ' filesystems', ' keyboard keymap lvm2 filesystems'
            )
            if user['drive']['luks'] is True:
                line = line.replace(' filesystems', ' encrypt filesystems')
        mkinitcpio.append(line)

    with open('/mnt/etc/mkinitcpio.conf', 'w+') as file:
        for line in mkinitcpio:
            file.write(line)

    # Run bootctl install
    cmd = Popen([
        'arch-chroot', '/mnt', 'bootctl', '--path=/boot', 'install'
    ], stdin=PIPE, stdout=PIPE)

    # Set loader.conf
    move(
        '/mnt/boot/loader/loader.conf', '/mnt/boot/loader/loader.backup',
        copy_function=copy2
    )
    copyfile('config/loader.conf', '/mnt/boot/loader/loader.conf')

    # Set new boot entry
    systemdboot = [
        'title Arch Linux',
        'linux /vmlinuz-{kernel}'.format(kernel=user['kernel']),
        'initrd /initramfs-{kernel}.img'.format(kernel=user['kernel'])
    ]
    if user['cpu']['microcode'] is not None:
        systemdboot.insert(
            2, 'initrd /{microcode}.img'
            .format(microcode=user['cpu']['microcode'])
        )
    if user['drive']['luks'] is True:
        systemdboot.append(
            'options cryptdevice=PARTUUID={uuid}:cryptlvm \
root=/dev/lvm/root quiet rw'.format(uuid=user['partitions']['partuuid'][1])
        )
    else:
        systemdboot.append(
            'options root=PARTUUID={uuid} quiet rw'
            .format(uuid=user['partitions']['partuuid'][1])
        )
    with open('/mnt/boot/loader/entries/arch.conf', 'w+') as file:
        for line in systemdboot:
            file.write(systemdboot)

    # Run bootctl update
    cmd = Popen([
        'arch-chroot', '/mnt', 'bootctl', '--path=/boot', 'update'
    ], stdin=PIPE, stdout=PIPE)

# Set grub (BIOS)
else:
    logging.info(trad('configure bootloader [grub2]'))

    # Run grub-install
    cmd = Popen([
        'arch-chroot', '/mnt', 'grub-install', '--target=i386-pc', '{boot}'
        .format(boot=user['drive']['boot'])
    ], stdin=PIPE, stdout=PIPE)

    # Set grub theme (Archlinux)
    copytree(
        'libraries/grub2-themes/Archlinux', '/boot/grub/themes/Archlinux',
        copy_function=copy2
    )
    with open('/mnt/etc/default/grub', 'r') as grub:
        grub_list = list(grub)
    move(
        '/mnt/etc/default/grub', '/mnt/etc/default/grub.backup',
        copy_function=copy2
    )
    grub = []
    for line in grub_list:
        line = re.sub(' +', ' ', line)
        line = line.replace('GRUB_GFXMODE=auto', 'GRUB_GFXMODE=1024x768')
        line = line.replace(
            '#GRUB_THEME="/path/to/gfxtheme"',
            'GRUB_THEME="/boot/grub/themes/Archlinux/theme.txt"'
        )
        grub.append(line)
    with open('/mnt/etc/default/grub', 'w+') as file:
        for line in grub:
            file.write(line)

    # Run grub-mkconfig
    cmd = Popen([
        'arch-chroot', '/mnt', 'grub-mkconfig', '-o', '/boot/grub/grub.cfg'
    ], stdin=PIPE, stdout=PIPE)


""" Configure desktop environment
    ______________________________________________________________________ """
if user['desktop_environment']['name'] is not None:
    logging.info(trad(
        'configure {desktop}'
        .format(desktop=user['desktop_environment']['name'])
    ))

    # Set keyboard layout
    with open('config/00-keyboard.conf', 'r') as keyboard:
        keyboard_list = list(keyboard)
    keyboard = []
    for line in keyboard_list:
        line = re.sub(' +', ' ', line)
        line.replace('keymap_code', user['keymap'])
        keyboard.append(line)
    with open('/mnt/etc/X11/xorg.conf.d/00-keyboard.conf', 'w+') as file:
        for line in grub:
            file.write(line)

    # Set xinitrc (window managers only)
    if 'xorg-xinit' in user['desktop_environment']['requirements']:
        move(
            'config/xinitrc.conf',
            '/mnt/home/{user}/.xinitrc'.format(user=user['username']),
            copy_function=copy2
        )
        with open(
            '/mnt/home/{user}/.xinitrc'.format(user=user['username']), 'a'
        ) as xinitrc:
            xinitrc.write(
                'exec {desktop}\n'.format(
                    desktop=user['desktop_environment']['name'].split(' ')[0]
                )
            )
        cmd = Popen([
            'arch-chroot', '/mnt', 'chmod', '770', '/mnt/home/{user}/.xinitrc'
            .format(user=user['username'])
        ], stdin=PIPE, stdout=PIPE)


""" Configure display manager
    ______________________________________________________________________ """
if user['display_manager']['name'] is not None:
    logging.info(trad(
        'configure {display}'
        .format(display=user['display_manager']['name'])
    ))

    # Enable display manager service
    if user['display_manager']['name'].lower() == 'xdm display manager':
        service = 'xdm-archlinux'
    else:
        service = user['display_manager']['name'].lower().split()[0]

    cmd = Popen([
        'arch-chroot', 'mnt', 'systemctl', 'enable', '{service}'
        .format(service=service)
    ], stdin=PIPE, stdout=PIPE)

    # Configure GDM
    if user['display_manager']['name'].lower() == 'gdm display manager':
        copyfile('config/xprofile.conf', '/mnt/etc/xprofile')

    # Configure LightDM
    elif user['display_manager']['name'].lower() == 'lightdm display manager':

        with open('/mnt/etc/lightdm/lightdm.conf', 'r') as lightdm:
            lightdm_list = list(lightdm)
        move(
            '/mnt/etc/lightdm/lightdm.conf',
            '/mnt/etc/lightdm/lightdm.backup',
            copy_function=copy2
        )
        lightdm = []
        for line in lightdm_list:
            line = re.sub(' +', ' ', line)
            line = line.replace(
                '#greeter-session=example-gtk-gnome',
                'greeter-session={session}'
                .format(session=user['display_manager']['session'])
            )
            line = line.replace(
                '#greeter-setup-script=',
                'greeter-setup-script=/usr/bin/numlockx on'
            )
            lightdm.append(line)
        with open('/mnt/etc/lightdm/lightdm.conf', 'w+') as file:
            for line in lightdm:
                file.write(line)

    # Configure SDDM
    elif user['display_manager']['name'].lower() == 'sddm display manager':

        cmd = Popen([
            'arch-chroot', '/mnt', 'sddm',
            '--example-config', '>', '/etc/sddm.backup'
        ], stdin=PIPE, stdout=PIPE)
        with open('/mnt/etc/sddm.backup', 'r') as sddm:
            sddm_list = list(sddm)
        sddm = []
        for line in sddm_list:
            line = re.sub(' +', ' ', line)
            line = line.replace(
                'Session=', 'Session={session}'
                .format(session=user['display_manager']['session'])
            )
            line = line.replace('Numlock=none', 'Numlock=on')
            sddm.append(line)
        with open('/mnt/etc/sddm.conf', 'w+') as file:
            for line in sddm:
                file.write(line)

    # Configure LXDM
    elif user['display_manager']['name'].lower() == 'lxdm display manager':

        with open('/mnt/etc/lxdm/lxdm.conf', 'r') as lxdm:
            lxdm_list = list(lxdm)
        move(
            '/mnt/etc/lxdm/lxdm.conf', '/mnt/etc/lxdm/lxdm.backup',
            copy_function=copy2
        )
        lxdm = []
        for line in lxdm_list:
            line = re.sub(' +', ' ', line)
            line = line.replace(
                '# session=/usr/bin/startlxde', 'session={session}'
                .format(session=user['display_manager']['session'])
            )
            line = line.replace('# numlock=0', 'numlock=1')
            line = line.replace('white=', 'white={user}'.format(
                user=user['username'])
            )
            lxdm.append(line)
        with open('/mnt/etc/lxdm/lxdm.conf', 'w+') as file:
            for line in lxdm:
                file.write(line)

    # Configure XDM
    elif user['display_manager']['name'].lower() == 'xdm display manager':

        with open(
                '/mnt/home/{user}/.session'.format(user=user['username']), 'a'
        ) as xdm:
            xdm.write(
                '{session}'.format(session=user['display_manager']['session'])
            )
        cmd = Popen([
            'arch-chroot', '/mnt', 'chmod', '770', '/mnt/home/{user}/.session'
            .format(user=user['username'])
        ], stdin=PIPE, stdout=PIPE)


""" Set user rights
    ______________________________________________________________________ """
if user['power'] is True:
    logging.info(
        trad('grant user {user} in sudoers'.format(user=user['username']))
    )
    with open('/mnt/etc/sudoers', 'a') as sudo:
        sudo.write(
            '\n## {user} privilege specification\n{user} ALL=(ALL) ALL'
            .format(user=user['username'])
        )
    logging.info(
        trad('add user {user} to all groups'.format(user=user['username']))
    )
    command_list = ['pwck', 'grpck']
    for command in command_list:
        cmd = Popen([
            'yes', '|', 'arch-chroot', '/mnt', '{command}'
            .format(command=command)
        ], stdin=PIPE, stdout=PIPE)

    group_list = check_output(
        'cut -d: -f1 /mnt/etc/group', shell=True
    ).decode('utf-8').split('\n')
    group_list = list(filter(None, group_list))
    for group in group_list:
        cmd = Popen([
            'arch-chroot', '/mnt', 'gpasswd', '-a', '{user}', '{group}'
            .format(user=user['username'], group=group)
        ], stdin=PIPE, stdout=PIPE)


""" Install AUR Helper
    ______________________________________________________________________ """
if user['aur_helper'] is not None:
    logging.info(
        trad('install {aur} AUR Helper'.format(aur=user['aur_helper']))
    )
    with open('/mnt/etc/sudoers', 'r') as sudo:
            sudo_list = list(sudo)
    sudo = []
    for line in sudo_list:
        line = re.sub(' +', ' ', line)
        line = line.replace(
            '{user} ALL=(ALL) ALL'.format(user=user['username']),
            '{user} ALL=(ALL) NOPASSWD: ALL'.format(user=user['username'])
        )
        sudo.append(line)
    with open('/mnt/etc/sudoers', 'w+') as file:
        for line in sudo:
            file.write(line)

    cmd = Popen([
        'arch-chroot', '/mnt', 'sudo', '-u', '{user}', 'git', 'clone',
        'https://aur.archlinux.org/{aur}.git', '/mnt/home/{user}/{aur}'
        .format(user=user['username'], aur=user['aur_helper'].lower())
    ], stdin=PIPE, stdout=PIPE)

    cmd = Popen([
        'arch-chroot', '/mnt', 'cd', '/home/{user}/{aur}', '&&', 'sudo',
        '-u', '{user}', 'makepkg', '--noconfirm', '--needed', '-sic'
        .format(user=user['username'], aur=user['aur_helper'].lower())
    ], stdin=PIPE, stdout=PIPE)

    with open('/mnt/etc/sudoers', 'r') as sudo:
            sudo_list = list(sudo)
    sudo = []
    for line in sudo_list:
        line = re.sub(' +', ' ', line)
        line = line.replace(
            '{user} ALL=(ALL) NOPASSWD: ALL'.format(user=user['username']),
            '{user} ALL=(ALL) ALL'.format(user=user['username'])
        )
        sudo.append(line)
    with open('/mnt/etc/sudoers', 'w+') as file:
        for line in sudo:
            file.write(line)
    rmtree(
        '/mnt/home/{user}/{aur}'
        .format(user=user['username'], aur=user['aur_helper'].lower())
    )


""" Clean dependencies
    ______________________________________________________________________ """
logging.info(trad('clean pacman cache and delete unused dependencies'))

try:
    dependencies_list = check_output(
        'arch-chroot /mnt pacman -Qdtd', shell=True
    ).decode('utf-8').split('\n')
    dependencies_list = list(filter(None, dependencies_list))
except CalledProcessError:
    pass

if dependencies_list != '':
    for dependency in dependencies_list:
        cmd = Popen([
            'arch-chroot', '/mnt', 'pacman', '--noconfirm',
            '-Rcsn', '{dependency}'.format(dependency=dependency)
        ], stdin=PIPE, stdout=PIPE)

cmd = Popen(
    ['arch-chroot', '/mnt', 'pacman', '--noconfirm', '-Sc'],
    stdin=PIPE, stdout=PIPE
)


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
