# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

import os
import json
import logging

from subprocess import Popen, PIPE


# Load user settings
with open(
    '{path}/temp/settings.json'.format(path=os.getcwd()),
    'r', encoding='utf-8'
) as settings:
    user = json.load(settings)


# Load archlinux packages
with open(
    '{path}/packages/archlinux.json'.format(path=os.getcwd()),
    'r', encoding='utf-8'
) as archlinux:
    packages = json.load(archlinux)


# Install base system
logging.info('install Arch Linux base system')
packages['arch'].append(packages['kernel'][user['kernel']])
if user['firmware']['driver'] is True:
    packages['arch'].append(packages['firmware'])
if user['aur_helper'] is True:
    packages['arch'].append(packages['devel'])
cmd = Popen([
    'yes', '|', 'pacstrap', '/mnt', packages['arch']
], stdin=PIPE, stdout=PIPE)


# Create FSTAB
logging.info('create file system table')
cmd = Popen([
    'genfstab', '-U', '-p', '/mnt', '>>' '/mnt/etc/fstab'
], stdin=PIPE, stdout=PIPE)


# Set timezone
logging.info('set timezone [{timezone}]'.format(timezone=user['timezone']))
cmd = Popen([
    'ln', '-sfv',
    '/usr/share/zoneinfo/{timezone}'.format(timezone=user['timezone']),
    '/mnt/etc/localtime'
], stdin=PIPE, stdout=PIPE)


# Set locale
logging.info('set locale [{locale}]'.format(locale=user['language']))
with open('/mnt/etc/locale.gen', 'a') as locale:
    locale.write('{language}.UTF-8 UTF-8\n'.format(user['language']))
cmd = Popen(['arch-chroot', '/mnt', 'locale-gen'], stdin=PIPE, stdout=PIPE)
cmd = Popen([
    'arch-chroot', '/mnt', 'export LANG={language}.UTF-8'
    .format(user['language'])
], stdin=PIPE, stdout=PIPE)
with open('/mnt/etc/locale.conf', 'w+') as locale:
    locale.write('LANG={language}.UTF-8\n'.format(user['language']))


# Set virtual console
logging.info('set virtual console [{keymap}]'.format(keymap=user['keymap']))
with open('/mnt/etc/vconsole.conf', 'w+') as vconsole:
    vconsole.write('KEYMAP={keymap}\n'.format(user['keymap']))


# Set hostname
logging.info('set hostname [{hostname}]'.format(hostname=user['hostname']))
with open('/mnt/etc/hostname', 'w+') as hostname:
    hostname.write('{hostname}\n'.format(user['hostname']))


# Set root password
logging.info('set root password')
cmd_args1 = Popen([
    'echo', 'root:{passwd}'.format(passwd=user['rootpasswd'])
], stdout=PIPE)
cmd_args2 = Popen(['chpasswd', '-e'], stdin=cmd_args1.stdout, stdout=PIPE)
cmd = cmd_args2.communicate()[0]


# Bootloader


# GPU driver


# Desktop Environment


# Display manager


# User rights


# AUR Helper


# Clean dependencies


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
