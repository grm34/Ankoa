# -*- coding: utf-8 -*-

'''
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
'''

import os
import sys
import json
import time
import logging

import subprocess
from shlex import quote


# Load user settings
with open(
        '{path}/temp/settings.json'.format(path=os.getcwd()),
        'r', encoding='utf-8'
) as settings:
    user = json.load(settings)


# Get existing partitions of selected drive
if user['drive']['name'] is not None:
    existing_partitions = subprocess.check_output(
        'lsblk -p -l -o "NAME,TYPE" {drive} | grep "part" | sed "s/ part//g"'
        .format(drive=quote(user['drive']['name'])), shell=True
    ).decode('utf-8').split('\n')
    existing_partitions = list(filter(None, existing_partitions))


# Get mountpoints of existing partitions
mounted_partitions = subprocess.check_output(
    r'lsblk -lo "MOUNTPOINT" | grep -v "MOUNTPOINT\|SWAP"', shell=True
).decode('utf-8').split('\n')
mounted_partitions = list(filter(None, mounted_partitions))


# Get existing LVM partitions
lv_list = subprocess.check_output(
    'lvs --aligned --noheadings --separator / -o vg_name,lv_name', shell=True
).decode('utf-8').split('\n')
lv_list = list(filter(None, lv_list))


# Get existing volume groups
vg_list = subprocess.check_output(
    'vgs --noheadings -o vg_name', shell=True
).decode('utf-8').split('\n')
vg_list = list(filter(None, vg_list))


# Get existing physical groups
pv_list = subprocess.check_output(
    'pvs --noheadings -o pv_name', shell=True
).decode('utf-8').split('\n')
pv_list = list(filter(None, pv_list))


# Umount existing partitions
for partition in mounted_partitions:
    if '/run/media/ARCH_' not in partition:
        logging.info('umount {partition}'.format(partition=partition))
        subprocess.check_output(
            'umount -fv {partition}'.format(partition=quote(partition)),
            shell=True
        )
        time.sleep(1)


# Prepare the drive
if user['drive']['name'] is not None:

    # Delete existing partitions
    for lv in lv_list:
        logging.info('delete {lv} (lvremove)'.format(lv=lv))
        subprocess.check_output(
            'lvremove -f -y {lv}'.format(lv=quote(lv)), shell=True
        )
        time.sleep(1)

    for vg in vg_list:
        logging.info('delete {vg} (vgremove)'.format(vg=vg))
        subprocess.check_output(
            'vgremove -f -y {vg}'.format(vg=quote(vg)), shell=True
        )
        time.sleep(1)

    for pv in pv_list:
        logging.info('delete {pv} (pvremove)'.format(pv=pv))
        subprocess.check_output(
            'pvremove -f -y {pv}'.format(pv=quote(pv)), shell=True
        )
        time.sleep(1)

    for partition in existing_partitions:
        logging.info('delete {partition} (fdisk)'.format(partition=partition))
        subprocess.check_output(
            r'printf "d\n\nw" | fdisk --wipe=always {drive}'.format(
                drive=quote(user['drive']['name'])), shell=True
        )
        time.sleep(1)
        subprocess.check_output('partprobe {drive}'.format(
                drive=quote(user['drive']['name'])), shell=True
        )
        time.sleep(1)

    # Format drive
    logging.info('format {drive}'.format(drive=user['drive']['name']))
    subprocess.check_output(
        'dd if=/dev/zero of={drive} bs=512 count=1 conv=notrunc'.format(
            drive=quote(user['drive']['name'])), shell=True
    )
    subprocess.check_output(
        'wipefs --force --all {drive}'.format(
            drive=quote(user['drive']['name'])), shell=True
    )
    logging.info(
        'create new {table} partition table on {drive}'.format(
            table=user['drive']['table'],
            drive=user['drive']['code'])
    )
    subprocess.check_output(
        r'printf "%s\nw" {partition_table_code} | fdisk {drive}'.format(
            partition_table_code=quote(user['drive']['code']),
            drive=quote(user['drive']['name'])), shell=True
    )
    time.sleep(1)
    subprocess.check_output('partprobe {drive}'.format(
            drive=quote(user['drive']['name'])), shell=True
    )
    time.sleep(1)

    # Create partitions
    for partition in user['partitions']['name']:
        if (
            (user['drive']['lvm'] is True) and (partition == 'root')
        ) or (
            (partition == 'home') and
            (user['partitions']['size'] == 'freespace')
        ):






    # Format partitions

# Mount partitions


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
