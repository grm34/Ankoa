# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

import os
import time
import json
import logging

from humanfriendly import parse_size, round_number
from subprocess import check_output, Popen, PIPE
from shlex import quote


# Load user settings
with open(
    '{path}/temp/settings.json'.format(path=os.getcwd()),
    'r', encoding='utf-8'
) as settings:
    user = json.load(settings)


# Get partitions drive ID
def partition_drive_id():
    drive_id_list = check_output(
        'lsblk -p -l -o "NAME,TYPE" {drive} | grep "part" | sed "s/ part//g"'
        .format(drive=quote(user['drive']['name'])), shell=True
    ).decode('utf-8').split('\n')
    user['partitions']['drive_id'] = list(filter(None, drive_id_list))
    return user


# Get partitions UUID
def partition_uuid():
    partuuid_list = []
    for drive_id in user['partitions']['drive_id']:
        partuuid = check_output(
            'blkid -o value -s PARTUUID {drive_id}'
            .format(drive_id=quote(drive_id)), shell=True
        ).decode('utf-8').replace('\n', '')
        partuuid_list.append(partuuid)
    user['partitions']['partuuid'] = list(filter(None, partuuid_list))
    return user


# Get existing partitions of selected drive
if user['drive']['name'] is not None:
    existing_partitions = check_output(
        'lsblk -p -l -o "NAME,TYPE" {drive} | grep "part" | sed "s/ part//g"'
        .format(drive=quote(user['drive']['name'])), shell=True
    ).decode('utf-8').split('\n')
    existing_partitions = list(filter(None, existing_partitions))


# Get mountpoints of existing partitions
mounted_partitions = check_output(
    r'lsblk -lo "MOUNTPOINT" | grep -v "MOUNTPOINT\|SWAP"', shell=True
).decode('utf-8').split('\n')
mounted_partitions = list(filter(None, mounted_partitions))


# Get existing LVM partitions
lv_list = check_output(
    'lvs --aligned --noheadings --separator / -o vg_name,lv_name', shell=True
).decode('utf-8').split('\n')
lv_list = list(filter(None, lv_list))


# Get existing volume groups
vg_list = check_output(
    'vgs --noheadings -o vg_name', shell=True
).decode('utf-8').split('\n')
vg_list = list(filter(None, vg_list))


# Get existing physical groups
pv_list = check_output(
    'pvs --noheadings -o pv_name', shell=True
).decode('utf-8').split('\n')
pv_list = list(filter(None, pv_list))


""" Umount existing partitions
    ______________________________________________________________________ """
for partition in mounted_partitions:
    if '/run/media/arch' not in partition.lower():
        logging.info('umount {partition}'.format(partition=partition))
        cmd_args = [
            'umount', '-f', '{partition}'.format(partition=partition)]
        Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)


""" Prepare the drive
    ______________________________________________________________________ """
if user['drive']['name'] is not None:

    # Delete existing partitions
    for lv in lv_list:
        logging.info('delete {lv}'.format(lv=lv))
        cmd_args = ['lvremove', '-q', '-f', '-y', '{lv}'.format(lv=lv)]
        Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    for vg in vg_list:
        logging.info('delete {vg}'.format(vg=vg))
        cmd_args = ['vgremove', '-q', '-f', '-y', '{vg}'.format(vg=vg)]
        Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    for pv in pv_list:
        logging.info('delete {pv}'.format(pv=pv))
        cmd_args = ['pvremove', '-q', '-f', '-y', '{pv}'.format(pv=pv)]
        Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    for partition in existing_partitions:
        logging.info('delete {partition}'.format(partition=partition))
        cmd_args1 = Popen(['printf', 'd\n\nw'], stdout=PIPE)
        cmd_args2 = Popen([
            'fdisk', '--wipe=always', '{drive}'
            .format(drive=user['drive']['name'])
        ], stdin=cmd_args1.stdout, stdout=PIPE)
        cmd = cmd_args2.communicate()[0]
        time.sleep(0.5)

    # Format drive
    logging.info(
        'format {drive} [{size}]'
        .format(drive=user['drive']['name'], size=user['drive']['size'])
    )
    cmd_args = [
        'wipefs', '-f', '-a', '{drive}'.format(drive=user['drive']['name'])
    ]
    Popen(cmd_args, stdin=PIPE, stdout=PIPE)
    check_output(
        'dd if=/dev/zero of={drive} bs=512 count=1 conv=notrunc'
        .format(drive=quote(user['drive']['name'])), shell=True
    )
    time.sleep(0.5)

    # Create new partition table
    logging.info(
        'create new {table} partition table on {drive}'
        .format(
            table=user['drive']['table'].upper(),
            drive=user['drive']['name'])
    )
    cmd_args1 = Popen([
        'echo', 'label: {table}'.format(table=user['drive']['table'])
    ], stdout=PIPE)
    cmd_args2 = Popen([
        'sfdisk', '-f', '-q', '--wipe=always', '{drive}'
        .format(drive=user['drive']['name'])
    ], stdin=cmd_args1.stdout, stdout=PIPE)
    cmd = cmd_args2.communicate()[0]
    time.sleep(0.5)

    """ Create DOS partitions
        __________________________________________________________________ """
    for partition, size in \
            zip(user['partitions']['name'], user['partitions']['size']):

        logging.info(
            'create new partition for {partition} [{size}] on {drive}'
            .format(
                partition=partition, size=size, drive=user['drive']['name']
            )
        )
        if size == 'freespace' or \
                ((user['drive']['lvm'] is True) and (partition == 'root')):
            size = '16T'
        size = parse_size(size.replace(',', '.'))
        cmd_args1 = Popen([
            'echo', 'size={size}'.format(size=round_number(int(size) / 1000))
        ], stdout=PIPE)
        cmd_args2 = Popen([
            'sfdisk', '-f', '-q', '--no-reread', '--wipe-partitions=always',
            '--append', '{drive}'.format(drive=user['drive']['name'])
        ], stdin=cmd_args1.stdout, stdout=PIPE)
        cmd = cmd_args2.communicate()[0]
        time.sleep(0.5)

    # Get ID and UUID of created partitions
    partition_drive_id()
    partition_uuid()

    """ Set partition types
        __________________________________________________________________ """
    for partition, drive_id in \
            zip(user['partitions']['name'], user['partitions']['drive_id']):

        if (user['firmware']['type'] == 'uefi') and (partition == 'boot'):
            gdisk_cmd = 't\nef00\nw'
            logging.info(
                'set EFI partition type for boot partition [{drive_id}]'
                .format(drive_id=drive_id)
            )
        elif ((user['drive']['lvm'] is True) and (partition == 'root')):
            gdisk_cmd = 't\n1\n8e00\nw'
            logging.info(
                'set LVM partition type for root partition [{drive_id}]'
                .format(drive_id=drive_id)
            )
        if 'gdisk_cmd' in locals():
            cmd_args1 = Popen([
                'printf', '{gdisk_cmd}'.format(gdisk_cmd=gdisk_cmd)
            ], stdout=PIPE)
            cmd_args2 = Popen([
                'gdisk', '{drive}'.format(drive=user['drive']['name'])
            ], stdin=cmd_args1.stdout, stdout=PIPE)
            cmd = cmd_args2.communicate()[0]
        time.sleep(0.5)

    """ LVM management
        __________________________________________________________________ """
    for partition, drive_id, size in \
            zip(
                user['partitions']['name'],
                user['partitions']['drive_id'],
                user['partitions']['size']
            ):

        # Create LVM Volume on root partition
        if (user['drive']['lvm'] is True) and (partition == 'root'):

            # LVM on LUKS
            if user['drive']['luks'] is True:
                logging.info(
                    'create LVM on LUKS [{drive_id}]'
                    .format(drive_id=drive_id)
                )
                Popen([
                    'cryptsetup', 'luksFormat', '{drive_id}'
                    .format(drive_id=drive_id)
                ], stdin=PIPE, stdout=PIPE)
                Popen([
                    'cryptsetup', 'open', '{drive_id}'
                    .format(drive_id=drive_id), 'cryptlvm'
                ], stdin=PIPE, stdout=PIPE)
                Popen([
                    'pvcreate', '-y', '/dev/mapper/cryptlvm'
                ], stdin=PIPE, stdout=PIPE)
                Popen([
                    'vgcreate', '-y', 'lvm', '/dev/mapper/cryptlvm'
                ], stdin=PIPE, stdout=PIPE)

            # LVM without LUKS
            else:
                logging.info(
                    'create LVM Volume on [{drive_id}]'
                    .format(drive_id=drive_id)
                )
                Popen([
                    'pvcreate', '-y', '{drive_id}'.format(drive_id=drive_id)
                ], stdin=PIPE, stdout=PIPE)
                Popen([
                    'vgcreate', '-y', 'lvm', '{drive_id}'
                    .format(drive_id=drive_id)
                ], stdin=PIPE, stdout=PIPE)

        # Create LVM Logical partitions
        if (user['drive']['lvm'] is True) and (partition != 'boot'):
            logging.info(
                'create {partition} LVM partition [{size}]'
                .format(partition=partition, size=size)
            )
            if size == 'freespace':
                size = '-l 100%FREE'
            else:
                size = '-L {size}'.format(size=size)
            Popen([
                'lvcreate', '-y', '{size}'.format(size=size), '{drive_id}'
                .format(drive_id=drive_id)
            ], stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    # Update ID and UUID of created partitions
    partition_drive_id()
    partition_uuid()

    """ Format partitions
        __________________________________________________________________ """
    for partition, drive_id, size, filesystem in \
            zip(
                user['partitions']['name'],
                user['partitions']['drive_id'],
                user['partitions']['size'],
                user['partitions']['filesystem']
            ):
        logging.info(
            'format {partition} partition [{filesystem}: {size}]'
            .format(partition=partition, filesystem=filesystem, size=size)
        )
        if filesystem == 'fat32':
            filesystem = 'fat -F32'

        if partition == 'swap':
            format_cmd = [
                'yes', '|', 'mkswap', '{drive_id}'.format(drive_id=drive_id)
            ]
        else:
            format_cmd = [
                'yes', '|', 'mkfs.{filesystem}'.format(filesystem=filesystem),
                '{drive_id}'.format(drive_id=drive_id)
            ]
        Popen(format_cmd, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)


""" Mount partitions
    ______________________________________________________________________ """
for partition, drive_id, mountpoint in \
        zip(user['partitions']['drive_id'], user['partitions']['mountpoint']):
    logging.info(
        'mount {drive_id} partition on {mountpoint} [{partition}]'
        .format(drive_id=drive_id, mountpoint=mountpoint, partition=partition)
    )
    if partition != 'swap':
        Popen([
            'swapon', '{drive_id}'.format(drive_id=drive_id)
        ], stdin=PIPE, stdout=PIPE)
    else:
        if not os.path.exists(mountpoint):
            os.makedirs(mountpoint)
        Popen([
            'mount', '{drive_id}'.format(partition=partition), '{mountpoint}'
            .format(mountpoint=mountpoint)
        ], stdin=PIPE, stdout=PIPE)
    time.sleep(0.5)


""" Update user settings
    ______________________________________________________________________ """
with open(
    '{path}/temp/settings.json'.format(path=os.getcwd()),
    'w', encoding='utf-8'
) as settings:
    json.dump(user, settings, ensure_ascii=False, indent=4)


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
