# -*- coding: utf-8 -*-

"""
Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================
"""

import gettext
import json
import logging
import os
import shlex
import time
from shlex import quote
from subprocess import PIPE, Popen, check_output

from humanfriendly import parse_size, round_number

# Load app settings
with open('{path}/json/app.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as app_settings:
    app = json.load(app_settings)


# Load user settings
with open('{path}/json/settings.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as settings:
    user = json.load(settings)


# Load app language
language = gettext.translation('PyArchboot', localedir='locales',
                               languages=['{lang}'.format(lang=app['lang'])])
trad = language.gettext


def partition_drive_id():
    """
    Get partitions drive ID and returns to user dictionary.

    Modules:
        subprocess -- check_output()
        shlex      -- quote()

    Returns:
        user {dictionary} -- options selected by the user
    """
    drive_id_list = check_output(
        'lsblk -p -l -o NAME,TYPE {drive} | grep part | sed "s/ part//g"'
        .format(drive=quote(user['drive']['name'])),
        shell=True).decode('utf-8').split('\n')

    user['partitions']['drive_id'] = list(filter(None, drive_id_list))
    return user


def partition_uuid():
    """
    Get partitions PARTUUID and returns to user dictionary.

    Modules:
        subprocess -- check_output()
        shlex      -- quote()

    Returns:
        user {dictionary} -- options selected by the user
    """
    partuuid_list = []
    for drive_id in user['partitions']['drive_id']:

        partuuid = check_output(
            'blkid -o value -s PARTUUID {drive_id}'
            .format(drive_id=quote(drive_id)),
            shell=True).decode('utf-8').replace('\n', '')

        partuuid_list.append(partuuid)

    user['partitions']['partuuid'] = list(filter(None, partuuid_list))
    return user


# Get existing partitions of selected drive
if user['drive']['name'] is not None:
    existing_partitions = check_output(
        'lsblk -p -l -o NAME,TYPE {drive} | grep part | sed "s/ part//g"'
        .format(drive=quote(user['drive']['name'])),
        shell=True).decode('utf-8').split('\n')

    existing_partitions = list(filter(None, existing_partitions))


# Get mountpoints of existing partitions
mounted_partitions = check_output(
    'lsblk -l -o MOUNTPOINT | grep -v MOUNTPOINT',
    shell=True).decode('utf-8').split('\n')

mounted_partitions = list(filter(None, mounted_partitions))


# Get existing LVM partitions
lv_list = check_output(
    'lvs --aligned --noheadings --separator / -o vg_name,lv_name',
    shell=True).decode('utf-8').split('\n')

lv_list = list(filter(None, lv_list))


# Get existing volume groups
vg_list = check_output('vgs --noheadings -o vg_name',
                       shell=True).decode('utf-8').split('\n')

vg_list = list(filter(None, vg_list))


# Get existing physical groups
pv_list = check_output('pvs --noheadings -o pv_name',
                       shell=True).decode('utf-8').split('\n')

pv_list = list(filter(None, pv_list))


"""
Umount existing partitions.
==============================================================================
"""

for partition in mounted_partitions:

    if 'swap' in partition.lower():
        swapon = check_output('lsblk -p -l -o NAME,MOUNTPOINT | grep SWAP',
                              shell=True).decode('utf-8').split('\n')

        swapon = list(filter(None, swapon))

        logging.info(trad('deactivate swap partition [{swap}]'
                          .format(swap=swapon[0].split()[0])))

        cmd = Popen(shlex.split('swapoff {swap}'
                                .format(swap=swapon[0].split()[0])),
                    stdin=PIPE, stdout=PIPE)

    if ('archiso' not in partition.lower()) and \
            ('swap' not in partition.lower()):

        logging.info(trad('umount {partition}').format(partition=partition))

        cmd_args = shlex.split('umount -f -R {partition}'.format(
            partition=partition))

        cmd = Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)


"""
Prepare the drive.
==============================================================================
"""

if user['drive']['name'] is not None:

    # Delete existing partitions
    for lv in lv_list:
        logging.info(trad('delete {lv}').format(lv=lv))

        cmd_args = shlex.split('lvremove -q -f -y {lv}'.format(lv=lv))
        cmd = Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    for vg in vg_list:
        logging.info(trad('delete {vg}').format(vg=vg))

        cmd_args = shlex.split('vgremove -q -f -y {vg}'.format(vg=vg))
        cmd = Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    for pv in pv_list:
        logging.info(trad('delete {pv}').format(pv=pv))

        cmd_args = shlex.split('pvremove -q -f -y {pv}'.format(pv=pv))
        cmd = Popen(cmd_args, stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    for partition in existing_partitions:
        logging.info(trad('delete {partition}').format(partition=partition))

        cmd_args1 = Popen(shlex.split('printf d\n\nw'), stdout=PIPE)
        cmd_args2 = Popen(shlex.split('fdisk --wipe=always {drive}'
                                      .format(drive=user['drive']['name'])),
                          stdin=cmd_args1.stdout, stdout=PIPE)

        cmd = cmd_args2.communicate()[0]
        time.sleep(0.5)

    # Format the disk
    logging.info(
        trad('format {drive} [{size}]')
        .format(drive=user['drive']['name'], size=user['drive']['size']))

    cmd_args = shlex.split('wipefs -f -a {drive}'
                           .format(drive=user['drive']['name']))
    cmd = Popen(cmd_args, stdin=PIPE, stdout=PIPE)

    cmd = check_output(
        'dd if=/dev/zero of={drive} bs=512 count=1 conv=notrunc'
        .format(drive=quote(user['drive']['name'])), shell=True)

    time.sleep(0.5)

    # Create new partition table
    logging.info(trad('create new {table} partition table on {drive}')
                 .format(table=user['drive']['table'].upper(),
                         drive=user['drive']['name']))

    cmd_args1 = Popen(shlex.split('printf label: {table}'
                                  .format(table=user['drive']['table'])),
                      stdout=PIPE)

    cmd_args2 = Popen(shlex.split('sfdisk -f -q --wipe=always {drive}'
                                  .format(drive=user['drive']['name'])),
                      stdin=cmd_args1.stdout, stdout=PIPE)

    cmd = cmd_args2.communicate()[0]
    time.sleep(0.5)

    """
    Create DOS partitions :
    =======================
    """

    for partition, size in \
            zip(user['partitions']['name'], user['partitions']['size']):

        logging.info(
            trad('create {partition} partition [{size}] on {drive}')
            .format(partition=partition, size=size,
                    drive=user['drive']['name']))

        if size == 'freespace' or \
                ((user['drive']['lvm'] is True) and (partition == 'root')):
            size = '16T'

        size = parse_size(size.replace(',', '.'))

        cmd_args1 = Popen(shlex.split('printf size={size}'
                                      .format(size=round_number(
                                          int(size) / 1000))),
                          stdout=PIPE)

        cmd_args2 = Popen(shlex.split(
            'sfdisk -f -q --no-reread --wipe-partitions=always \
--append {drive}'.format(drive=user['drive']['name'])),
            stdin=cmd_args1.stdout, stdout=PIPE)

        cmd = cmd_args2.communicate()[0]
        time.sleep(0.5)

    # Get ID and UUID of created partitions
    partition_drive_id()
    partition_uuid()

    """
    Set partition types :
    =====================
    """

    for partition, drive_id in \
            zip(user['partitions']['name'], user['partitions']['drive_id']):

        if (user['firmware']['type'] == 'uefi') and (partition == 'boot'):
            gdisk_cmd = 't\nef00\nw'

            logging.info(
                trad('set EFI partition type for boot partition [{drive_id}]')
                .format(drive_id=drive_id))

        elif ((user['drive']['lvm'] is True) and (partition == 'root')):
            gdisk_cmd = 't\n1\n8e00\nw'

            logging.info(
                trad('set LVM partition type for root partition [{drive_id}]')
                .format(drive_id=drive_id))

        if 'gdisk_cmd' in locals():
            cmd_args1 = Popen(shlex.split('printf {gdisk_cmd}'
                                          .format(gdisk_cmd=gdisk_cmd)),
                              stdout=PIPE)

            cmd_args2 = Popen(shlex.split('gdisk {drive}'
                                          .format(
                                              drive=user['drive']['name'])),
                              stdin=cmd_args1.stdout, stdout=PIPE)

            cmd = cmd_args2.communicate()[0]

        time.sleep(0.5)

    """
    LVM management :
    ================
    """

    for partition, drive_id, size in \
            zip(user['partitions']['name'],
                user['partitions']['drive_id'],
                user['partitions']['size']):

        # Create LVM Volume on root partition
        if (user['drive']['lvm'] is True) and (partition == 'root'):

            # LVM on LUKS
            if user['drive']['luks'] is True:

                logging.info(trad('create LVM on LUKS [{drive_id}]')
                             .format(drive_id=drive_id))

                cmd = Popen(shlex.split('cryptsetup luksFormat {drive_id}'
                                        .format(drive_id=drive_id)),
                            stdin=PIPE, stdout=PIPE)

                cmd = Popen(shlex.split('cryptsetup open {drive_id} cryptlvm'
                                        .format(drive_id=drive_id)),
                            stdin=PIPE, stdout=PIPE)

                cmd = Popen(shlex.split('pvcreate -y /dev/mapper/cryptlvm'),
                            stdin=PIPE, stdout=PIPE)

                cmd = Popen(shlex.split(
                    'vgcreate -y lvm /dev/mapper/cryptlvm'), stdin=PIPE,
                    stdout=PIPE)

            # LVM without LUKS
            else:
                logging.info(trad('create LVM Volume on [{drive_id}]')
                             .format(drive_id=drive_id))

                cmd = Popen(shlex.split('pvcreate -y {drive_id}'
                                        .format(drive_id=drive_id)),
                            stdin=PIPE, stdout=PIPE)

                cmd = Popen(shlex.split('vgcreate -y lvm {drive_id}'
                                        .format(drive_id=drive_id)),
                            stdin=PIPE, stdout=PIPE)

        # Create LVM Logical partitions
        if (user['drive']['lvm'] is True) and (partition != 'boot'):

            logging.info(trad('create {partition} LVM partition [{size}]')
                         .format(partition=partition, size=size))

            if size == 'freespace':
                size = '-l 100%FREE'
            else:
                size = '-L {size}'.format(size=size)

            cmd = Popen(shlex.split('lvcreate -y {size} {drive_id}'
                                    .format(size=size, drive_id=drive_id)),
                        stdin=PIPE, stdout=PIPE)
        time.sleep(0.5)

    # Update ID and UUID of created partitions
    partition_drive_id()
    partition_uuid()

    """
    Format the partitions :
    =======================
    """

    for partition, drive_id, size, filesystem in \
            zip(user['partitions']['name'],
                user['partitions']['drive_id'],
                user['partitions']['size'],
                user['partitions']['filesystem']):

        logging.info(
            trad('format {partition} partition [{filesystem}] [{size}]')
            .format(partition=partition, filesystem=filesystem, size=size))

        if filesystem == 'fat32':
            filesystem = 'fat -F32'

        if partition == 'swap':
            format_cmd = 'yes | mkswap {drive_id}'.format(drive_id=drive_id)
        else:
            format_cmd = 'yes | mkfs.{filesystem} {drive_id}'.format(
                filesystem=filesystem, drive_id=drive_id)

        cmd = check_output(format_cmd, shell=True)
        time.sleep(0.5)


"""
Mount the partitions.
==============================================================================
"""

for mountorder, partition, drive_id, mountpoint in \
        sorted(zip(user['partitions']['mountorder'],
                   user['partitions']['name'],
                   user['partitions']['drive_id'],
                   user['partitions']['mountpoint'])):

    logging.info(trad(
        'mount {partition} partition [{drive_id}] on {mountpoint}').format(
            partition=partition, mountpoint=mountpoint, drive_id=drive_id))

    if partition == 'swap':
        cmd = Popen(shlex.split('swapon {drive_id}'
                                .format(drive_id=drive_id)),
                    stdin=PIPE, stdout=PIPE)
    else:
        if not os.path.exists(mountpoint):
            os.makedirs(mountpoint)

        cmd = Popen(shlex.split('mount {drive_id} {mountpoint}'
                                .format(drive_id=drive_id,
                                        mountpoint=mountpoint)),
                    stdin=PIPE, stdout=PIPE)
    time.sleep(0.5)


"""
Update user settings.
==============================================================================
"""

with open('{path}/json/settings.json'.format(path=os.getcwd()), 'w',
          encoding='utf-8') as settings:
    json.dump(user, settings, ensure_ascii=False, indent=4)


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
