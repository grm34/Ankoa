# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

import os
import re
import sys
import json
import requests
import logging

import inquirer
from inquirer import errors
from inquirer.themes import GreenPassion

from subprocess import check_output
from passlib.hash import pbkdf2_sha256
from humanfriendly import (parse_size, format_size)

import gettext
language = gettext.translation('settings', 'locales')
trad = language.gettext

""" Settings module

    This module uses python-inquirer and returns a dictionary
    of the options selected by the user. Sensitive data like passwords
    will be hashed (sha256) before its stored for security reasons.
    ______________________________________________________________________ """


def system_settings():
    """ Get required system settings

        Modules:
            subprocess  -- check_output
            requests    -- get
            json        -- decode

        Returns:
            drive_list      -- array of available drives
            partition_list  -- array of available partitions
            gpu_list        -- array of available VGA Controllers
            ipinfo          -- dictionary of IP Address Data
            firmware        -- string of system firmware (bios or uefi)
            efi             -- string of uefi firmware type (x86 or x64)
            size_regex      -- raw string literal to valid partition sizes
    """

    # Get available drives
    drive_list = check_output(
        'lsblk -I 8 -d -p -o "NAME,SIZE,MODEL" | grep -v "NAME"', shell=True
    ).decode('utf-8').split('\n')
    drive_list = list(filter(None, drive_list))
    drive_list.insert(0, (trad('Use already formatted partitions'), None))

    # Get available partitions
    partition_list = check_output(
        'lsblk -p -l -o "NAME,SIZE,FSTYPE,TYPE,MOUNTPOINT,MODEL" | \
    grep "part" | sed "s/part //g"', shell=True).decode('utf-8').split('\n')
    partition_list = list(filter(None, partition_list))

    # Get available VGA controllers
    gpu_list = check_output('lspci | grep -e VGA -e 3D | sed "s/.*: //g" | \
    sed "s/Graphics Controller //g"', shell=True).decode('utf-8').split('\n')
    gpu_list = list(filter(None, gpu_list))

    # Get ip, country and timezone
    ipinfo = requests.get('https://ipinfo.io?token=26d03faada92e8').json()

    # Get firmware
    if os.path.isdir('/sys/firmware/efi/efivars'):
        firmware = 'uefi'
        if '64' in open('/sys/firmware/efi/fw_platform_size').read():
            efi = 'x64'
        else:
            efi = 'x86'
    else:
        firmware = 'bios'
        efi = None

    # Raw string literal to valid partition sizes
    size_regex = r'^[1-9]{1}[0-9]{0,2}(,[0-9]{1,3}){0,1}(M|G|T){1}$'

    return (
        drive_list, partition_list, gpu_list, ipinfo,
        firmware, efi, size_regex
    )


""" Validation Functions: ensure valid user answers

    Arguments:
        user {dictionary}  -- options selected by the user
        response {string}  -- answers

    Raises:
        errors.ValidationError: display a short description for valid entry

    Returns:
        boolean  -- True
    ______________________________________________________________________ """


def boot_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 100000000) or \
            (parse_size(response.replace(',', '.')) > 2000000000) or (
                parse_size(response.replace(',', '.')) >
                parse_size(user['drive'].split()[1].replace(',', '.'))
            ):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for BOOT "{response}" (e.q., 512M) Minimum [100M] \
Maximum [2G] Remaining [{drive_size}]'.format(
                response=response,
                drive_size=user['drive'].split()[1]
            )
        ))
    return True


def root_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 5000000000) or \
            (parse_size(response.replace(',', '.')) > 16000000000000) or \
            (parse_size(response.replace(',', '.')) > (
                int(parse_size(user['drive'].split()[1].replace(',', '.'))) -
                int(parse_size(user['boot_size'].replace(',', '.')))
            )):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for ROOT "{response}" (e.q., 25G) Minimum [5G] \
Maximum [16T] Remaining [{available}]'.format(
                response=response,
                available=format_size(
                    int(
                        parse_size(user['drive'].split()[1].replace(',', '.'))
                    ) - int(parse_size(user['boot_size'].replace(',', '.')))
                )
            )
        ))
    return True


def swap_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 1000000000) or \
            (parse_size(response.replace(',', '.')) > 32000000000) or \
            (parse_size(response.replace(',', '.')) > (
                int(parse_size(user['drive'].split()[1].replace(',', '.'))) -
                int(parse_size(user['boot_size'].replace(',', '.'))) -
                update_root_size(user)
            )):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for SWAP "{response}" (e.q., 2G) Minimum [1G] \
Maximum [32G] Remaining [{available}]'.format(
                response=response,
                available=format_size(
                    int(
                        parse_size(user['drive'].split()[1].replace(',', '.'))
                    ) -
                    int(parse_size(user['boot_size'].replace(',', '.'))) -
                    update_root_size(user)
                )
            )
        ))
    return True


def home_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 4000000000) or \
            (parse_size(response.replace(',', '.')) > 16000000000000) or \
            (parse_size(response.replace(',', '.')) > (
                int(parse_size(user['drive'].split()[1].replace(',', '.'))) -
                int(parse_size(user['boot_size'].replace(',', '.'))) -
                int(parse_size(user['root_size'].replace(',', '.'))) -
                update_swap_size(user)
            )):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for HOME "{response}" (e.q., 100G) Minimum [4G] \
Maximum [16T] Remaining [{available}]'.format(
                response=response,
                available=format_size(
                    int(parse_size(
                        user['drive'].split()[1].replace(',', '.')
                    )) -
                    int(parse_size(user['boot_size'].replace(',', '.'))) -
                    int(parse_size(user['root_size'].replace(',', '.'))) -
                    update_swap_size(user)
                )
            )
        ))
    return True


def timezone_validation(user, response):
    timezone_list = open(
        '{path}/libraries/timezone'.format(path=os.getcwd())
    ).read()
    if ('{response}\n'.format(response=response) not in timezone_list) or \
            (response == ''):
        raise errors.ValidationError('', reason=trad(
            'Invalid timezone "{response}" (e.q., Europe/Paris)'
            .format(response=response)
        ))
    return True


def language_validation(user, response):
    language_list = open(
        '{path}/libraries/language'.format(path=os.getcwd())
    ).read()
    if ('{response}\n'.format(response=response) not in language_list) or \
            (response == ''):
        raise errors.ValidationError('', reason=trad(
            'Invalid language code "{response}" (e.q., fr_FR)'
            .format(response=response)
        ))
    return True


def hostname_validation(user, response):
    if not re.match(r'^[a-zA-Z0-9][-a-zA-Z0-9_]{1,31}$', response):
        raise errors.ValidationError('', reason=trad(
            'Invalid hostname "{response}" (e.q., my-computer)'
            .format(response=response)
        ))
    return True


def passwd_validation(user, response):
    if not re.match(r'^(?=.*[A-Za-z])(?=.*\d)[\S]{8,}$', response):
        raise errors.ValidationError('', reason=trad(
            'Password should be at least 8 chars long with \
one letter and one digit !')
        )
    return True


def username_validation(user, response):
    if not re.match(
        r'^[a-z_]([a-z0-9_-]{0,31}|[a-z0-9_-]{0,30}\$)$', response
    ):
        raise errors.ValidationError('', reason=trad(
            'Invalid username "{response}" (e.q., JohnDoe)'
            .format(response=response)
        ))
    return True


""" Ignore Functions: bypass conditions for questions

    Arguments:
        user {dictionary}  -- options selected by the user

    Returns:
        boolean  -- True
    ______________________________________________________________________ """


def ignore_lvm(user):
    if (user['drive'] is None) or (firmware == 'bios'):
        return True


def ignore_luks(user):
    if user['lvm'] is False:
        return True


def ignore_boot_size(user):
    if user['drive'] is None:
        return True


def ignore_root_freespace(user):
    if (user['drive'] is None) or ('Home' in user['optional_partitions']):
        return True


def ignore_root_size(user):
    if (user['drive'] is None) or (user['root_freespace'] is True):
        return True


def ignore_swap_size(user):
    if (user['drive'] is None) or ('Swap' not in user['optional_partitions']):
        return True


def ignore_home_freespace(user):
    if (user['drive'] is None) or ('Home' not in user['optional_partitions']):
        return True


def ignore_home_size(user):
    if (user['drive'] is None) or \
            ('Home' not in user['optional_partitions']) or \
            (user['home_freespace'] is True):
        return True


def ignore_required_partition_id(user):
    if user['drive'] is not None:
        return True


def ignore_swap_id(user):
    if (user['drive'] is not None) or \
            ('Swap' not in user['optional_partitions']):
        return True


def ignore_home_id(user):
    if (user['drive'] is not None) or \
            ('Home' not in user['optional_partitions']):
        return True


def ignore_timezone(user):
    if user['timezone'] is not None:
        return True


def ignore_desktop_extras(user):
    if (user['desktop'] is None) or \
            (user['desktop'].lower() not in ['gnome', 'kde', 'mate', 'xfce',
                                             'deepin', 'lxqt']):
        return True


def ignore_display_manager(user):
    if user['desktop'] is None:
        return True


def ignore_lightdm_greeter(user):
    if (user['desktop'] is None) or (user['display_manager'] != 'LightDM'):
        return True


def ignore_gpu_driver(user):
    if (user['desktop'] is None) or (gpu_list == ['']):
        return True


def ignore_vga_controller(user):
    if user['gpu_driver'] is False:
        return True


def ignore_nvidia_proprietary(user):
    if (user['gpu_driver'] is False) or \
            ('nvidia' not in user['vga_controller']):
        return True


""" Update Functions
    ______________________________________________________________________ """


def update_partition_list(user):
    """ Deletion of partitions selected by the user,
        to display an updated array after selection.

        Arguments:
            user {dictionary}  -- options selected by the user

        Returns:
            dictionary  -- updated array of available partitions
    """
    if user['boot_id'] in partition_list:
        partition_list.remove(user['boot_id'])

    if 'root_id' in user:
        if user['root_id'] in partition_list:
            partition_list.remove(user['root_id'])

    if 'swap_id' in user:
        if user['swap_id'] in partition_list:
            partition_list.remove(user['swap_id'])

    return partition_list


def update_root_size(user):
    """Assign integer if root size == freespace
       Required to calculate remaining disk space.

    Arguments:
        user {dictionary} -- options selected by the user

    Returns:
        integer -- zero or partition size in bytes
    """
    if user['root_size'] is None:
        user['root_size'] = '0'
    return int(parse_size(user['root_size']))


def update_swap_size(user):
    """Assign integer if no swap partition
       Required to calculate remaining disk space.

    Arguments:
        user {dictionary} -- options selected by the user

    Returns:
        integer -- zero or partition size in bytes
    """
    if user['swap_size'] is None:
        user['swap_size'] = '0'
    return int(parse_size(user['swap_size']))


def update_inquirer():
    """ Update and sort dictionary containing user options.
        Delete unused variables when values stored.

        Returns:
            dictionary -- options selected by the user
    """

    # Append drive
    if user['drive'] is None:
        user['drive'] = {'name': user['drive']}
    else:
        user['drive'] = {
            'name': user['drive'].split()[0],
            'size': user['drive'].split()[1],
            'model': user['drive'].split()[2],
            'lvm': user['lvm'],
            'luks': user['luks']
        }
        if firmware == 'uefi':
            user['drive']['table'] = 'gpt'
        else:
            user['drive']['table'] = 'mbr'

    # Append partitions (DEFAULT MODE)
    if user['drive'] is not None:
        if user['root_freespace'] is True:
            user['root_size'] = 'freespace'
        user['partitions'] = {
            'name': ['boot', 'root'],
            'size': [user['boot_size'], user['root_size']],
            'filesystem': ['fat32', 'ext4'],
            'mountpoint': ['/mnt/boot', '/mnt']
        }

        if 'Swap' in user['optional_partitions']:
            user['partitions']['name'].insert(1, 'swap')
            user['partitions']['size'].insert(1, user['swap_size'])
            user['partitions']['filesystem'].insert(1, 'swap')
            user['partitions']['mountpoint'].insert(1, 'swap')

        if 'Home' in user['optional_partitions']:
            user['partitions']['name'].append('home')
            if user['home_freespace'] is True:
                user['home_size'] = 'freespace'
            user['partitions']['size'].append(user['home_size'])
            user['partitions']['filesystem'].append('ext4')
            user['partitions']['mountpoint'].append('/mnt/home')

    # Append partitions (CUSTOM MODE)
    else:
        user['partitions'] = {
            'name': ['boot', 'root'],
            'drive_id': [
                user['boot_id'].split()[0], user['root_id'].split()[0]
            ],
            'mountpoint': ['/mnt/boot', '/mnt']
        }

        if user['swap_id'] is not None:
            user['partitions']['name'].insert(1, 'swap')
            user['partitions']['drive_id'].insert(
                1, user['swap_id'].split()[0]
            )
            user['partitions']['mountpoint'].insert(1, 'swap')

        if user['home_id'] is not None:
            user['partitions']['name'].append('home')
            user['partitions']['drive_id'].append(
                user['home_id'].split()[0]
            )
            user['partitions']['mountpoint'].append('/mnt/home')

    # Append desktop
    user['desktop'] = {
        'name': user['desktop'],
        'extras': user['desktop_extras']
    }

    # Append GPU
    if user['gpu_driver'] is True:
        if 'nvidia' in user['vga_controller'].lower():
            gpu_driver = 'nvidia'

        elif ('ATI' in user['vga_controller']) or \
                ('AMD' in user['vga_controller']):
            gpu_driver = 'amd'

        elif 'intel' in user['vga_controller'].lower():
            gpu_driver = 'intel'

        else:
            gpu_driver = 'vesa'
    else:
        gpu_driver = None
    user['gpu'] = {
        'model': user['vga_controller'],
        'driver': gpu_driver,
        'hardvideo': user['hardvideo'],
        'proprietary': user['gpu_proprietary']
    }

    # Append display manager
    user['desktop_environment'] = {
        'name': user['desktop'],
        'display_manager': user['display_manager'],
        'greeter': user['greeter']
    }

    # Hash and append passwords
    rootpasswd = pbkdf2_sha256.hash(user['root_passwd'])
    userpasswd = pbkdf2_sha256.hash(user['user_passwd'])
    user['passwords'] = {'root': rootpasswd, 'user': userpasswd}

    # Append keymap
    if 'keymap' not in locals():
        user['keymap'] = user['language'].split('_')[0]

    # Append firmware
    user['firmware'] = {'type': firmware, 'version': efi}

    # Append ip and country
    user['ip'] = ipinfo['ip']
    user['country'] = ipinfo['country']

    # Delete unused entries
    unused_entries = [
        'root_freespace', 'home_freespace', 'optional_partitions', 'boot_id',
        'boot_size', 'root_size', 'swap_size', 'home_size', 'root_id',
        'swap_id', 'home_id', 'lvm', 'luks', 'user_passwd', 'root_passwd',
        'gpu_driver', 'vga_controller', 'gpu_proprietary', 'desktop',
        'desktop_extras', 'hardvideo', 'display_manager', 'greeter'
    ]
    for unused in unused_entries:
        del user[unused]

    # Return dictionary
    return user


""" Python Inquirer

    Load system settings.
    Create an array of questions.

    Inquirer should ease the process of asking end user questions,
    parsing, validating answers, managing hierarchical prompts
    and providing error feedback.

    https://magmax.org/python-inquirer/index.html
    ______________________________________________________________________ """
(
    drive_list, partition_list, gpu_list, ipinfo, firmware, efi, size_regex
) = system_settings()

questions = [
    inquirer.List(                              # DRIVE
        'drive',
        message=trad('Select the drive to use'),
        choices=drive_list,
        carousel=True
    ),
    inquirer.Confirm(                           # LVM
        'lvm',
        message=trad('Do you wish use Logical Volume Manager (LVM)'),
        ignore=ignore_lvm
    ),
    inquirer.Confirm(                           # LUKS
        'luks',
        message=trad('Do you wish to encrypt the drive (LVM on LUKS)'),
        ignore=ignore_luks
    ),
    inquirer.Checkbox(                          # OPTIONAL PARTITIONS
        'optional_partitions',
        message=trad('Select optional partitions'),
        choices=['Swap', 'Home'],
        default=None
    ),
    inquirer.Text(                              # BOOT SIZE
        'boot_size',
        message=trad('Enter desired size for boot partition'),
        validate=boot_size_validation,
        ignore=ignore_boot_size,
    ),
    inquirer.Confirm(                           # ROOT FREE SPACE
        'root_freespace',
        message=trad('Do you wish use free space for root partition'),
        ignore=ignore_root_freespace
    ),
    inquirer.Text(                              # ROOT SIZE
        'root_size',
        message=trad('Enter desired size for root partition'),
        default=None,
        validate=root_size_validation,
        ignore=ignore_root_size
    ),
    inquirer.Text(                              # SWAP SIZE
        'swap_size',
        message=trad('Enter desired size for swap partition'),
        default=None,
        validate=swap_size_validation,
        ignore=ignore_swap_size
    ),
    inquirer.Confirm(                           # HOME FREE SPACE
        'home_freespace',
        message=trad('Do you wish use free space for home partition'),
        ignore=ignore_home_freespace
    ),
    inquirer.Text(                              # HOME SIZE
        'home_size',
        message=trad('Enter desired size for home partition'),
        validate=home_size_validation,
        ignore=ignore_home_size
    ),
    inquirer.List(                              # BOOT DRIVE ID
        'boot_id',
        message=trad('Select boot partition'),
        choices=partition_list,
        carousel=True,
        ignore=ignore_required_partition_id
    ),
    inquirer.List(                              # ROOT DRIVE ID
        'root_id',
        message=trad('Select root partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_required_partition_id
    ),
    inquirer.List(                              # SWAP DRIVE ID
        'swap_id',
        message=trad('Select swap partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_swap_id
    ),
    inquirer.List(                              # HOME DRIVE ID
        'home_id',
        message=trad('Select home partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_home_id
    ),
    inquirer.List(                              # SELECT TIMEZONE
        'timezone',
        message=trad('Select timezone'),
        choices=[ipinfo['timezone'], (trad('Custom timezone'), None)],
        default=ipinfo['timezone'],
        carousel=True
    ),
    inquirer.Text(                              # ENTER TIMEZONE
        'timezone',
        message=trad('Enter desired timezone'),
        validate=timezone_validation,
        ignore=ignore_timezone
    ),
    inquirer.Text(                              # LANGUAGE
        'language',
        message=trad('Enter language code'),
        validate=language_validation
    ),
    inquirer.Text(                              # HOSTNAME
        'hostname',
        message=trad('Enter hostname'),
        validate=hostname_validation
    ),
    inquirer.Password(                          # ROOT PASSWD
        'root_passwd',
        message=trad('Enter password for root'),
        validate=passwd_validation
    ),
    inquirer.Text(                              # USERNAME
        'username',
        message=trad('Enter username'),
        validate=username_validation
    ),
    inquirer.Password(                          # USER PASSWD
        'user_passwd',
        message=trad('Enter password for user {username}'),
        validate=passwd_validation
    ),
    inquirer.List(                              # LINUX KERNEL
        'kernel',
        message=trad('Select Linux Kernel'),
        choices=[
            ('Linux Default', 'linux'),
            ('Linux Hardened', 'linux-hardened'),
            ('Linux LTS', 'linux-lts'), ('Linux ZEN', 'linux-zen')
        ],
        carousel=True
    ),
    inquirer.Confirm(                           # LINUX FIRMWARE
        'linux_firmware',
        message=trad('Do you wish to install Linux Firmware'),
        default=True
    ),
    inquirer.List(                              # DESKTOP ENVIRONMENT
        'desktop',
        message=trad('Select Desktop Environment'),
        choices=[
            None, 'Gnome', 'KDE', 'Deepin', 'Cinnamon', 'Mate',
            'Budgie', 'XFCE', 'LXDE', 'LXQT', 'Enlightenment',
            'Awesome', 'Xmonad', 'i3'
        ],
        carousel=True
    ),
    inquirer.Confirm(                           # DESKTOP EXTRAS
        'desktop_extras',
        message=trad('Do you wish to install {desktop} extras'),
        ignore=ignore_desktop_extras
    ),
    inquirer.List(                              # DISPLAY MANAGER
        'display_manager',
        message=trad('Select Display Manager'),
        choices=['Gdm', 'LightDM', 'Sddm', 'Lxdm', 'Xdm'],
        carousel=True,
        ignore=ignore_display_manager
    ),
    inquirer.List(                              # LIGHTDM GREETER
        'greeter',
        message=trad('Select LightDM Greeter'),
        choices=['Gtk', 'Pantheon', 'Webkit', 'Litarvan'],
        carousel=True,
        ignore=ignore_lightdm_greeter
    ),
    inquirer.Confirm(                           # GPU DRIVER
        'gpu_driver',
        message=trad('Do you wish to install GPU driver'),
        ignore=ignore_gpu_driver
    ),
    inquirer.List(                              # SELECT GPU
        'vga_controller',
        message=trad('Select GPU Controller'),
        choices=gpu_list,
        carousel=True,
        ignore=ignore_vga_controller
    ),
    inquirer.Confirm(                           # HARDWARE VIDEO
        'hardvideo',
        message=trad(
            'Do you wish to install Hardware video acceleration'
        ),
        ignore=ignore_vga_controller
    ),
    inquirer.Confirm(                           # NVIDIA PROPRIETARY
        'gpu_proprietary',
        message=trad('Do you wish to install proprietary drivers'),
        ignore=ignore_nvidia_proprietary
    ),
    inquirer.List(                              # AUR HELPER
        'aur_helper',
        message=trad('Select AUR Helper'),
        choices=[
            None, 'Yay', 'Pamac-aur', 'Trizen',
            'Pacaur', 'Pakku', 'Pikaur'
        ],
        carousel=True
    ),
    inquirer.Confirm(                           # USER POWER
        'power',
        message=trad('Do you wish add to all groups user {username}'),
        default=True
    ),
    inquirer.Confirm(                           # CONFIRM
        'confirm',
        message=trad('Do you wish to install Arch Linux now')
    )
]


""" Start Inquirer -----------------------------------------------------------

    Call the prompt render.
    Update user dictionary.
    Prompt installation confirmation.
    Call again the prompt render on negative.
    Otherwise store dictionary as json file in temp folder.
"""
user = inquirer.prompt(questions, theme=GreenPassion())
update_inquirer()

if user['confirm'] is False:
    logging.info(trad('installation aborted. Please try again !'))
    user = inquirer.prompt(questions, theme=GreenPassion())
    update_inquirer()
else:
    del user['confirm']
    with open(
        '{path}/temp/settings.json'.format(path=os.getcwd()),
        'w', encoding='utf-8'
    ) as settings:
        json.dump(user, settings, ensure_ascii=False, indent=4)


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
