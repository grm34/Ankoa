# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

import os
import re
import sys
import json
import logging

import inquirer
from inquirer import errors
from inquirer.themes import load_theme_from_dict

from termcolor import colored
from requests import (get, ConnectionError)
from crypt import (crypt, mksalt, METHOD_SHA512)
from humanfriendly import (parse_size, format_size)
from subprocess import (check_output, CalledProcessError)
from shlex import quote

import gettext
language = gettext.translation('PyArchboot', 'locales')
trad = language.gettext


""" Manager module

    This module uses python-inquirer and returns a dictionary
    of the options selected by the user with the corresponding
    packages, added from JSON file (json/packages.json).
    For security reasons sensitive data like passwords will be
    hashed with crypt before its stored (SHA-512).
    ______________________________________________________________________ """

# Load inquirer theme
with open('{path}/json/theme.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as theme_json:
    theme = json.load(theme_json)


# Load archlinux packages
with open('{path}/json/packages.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as packages_list:
    packages = json.load(packages_list)


def system_settings():
    """ Get required system settings

        Modules:
            subprocess -- check_output
            requests   -- get
            json       -- decode

        Returns:
            drive_list     {array} -- available drives
            partition_list {array} -- available partitions
            cpu           {string} -- CPU model
            gpu_list       {array} -- available VGA Controllers
            ntfs         {boolean} -- NTFS support
            lvm          {boolean} -- LVM support
            luks         {boolean} -- LUKS support
            ipinfo    {dictionary} -- IP Address Data
            mirrors       {string} -- fastest mirrors
            firmware      {string} -- system firmware (bios or uefi)
            efi           {string} -- uefi firmware type (x86 or x64)
            size_regex    {string} -- raw string literal to valid sizes
    """

    # Get available drive(s)
    try:
        drive_list = check_output(
            'lsblk -I 8 -d -p -o NAME,SIZE,MODEL | grep -v NAME',
            shell=True).decode('utf-8').split('\n')
        drive_list = list(filter(None, drive_list))
        drive_list.insert(0, (trad('Use already formatted partitions'), None))
    except CalledProcessError:
        logging.error(trad('no drive detected !'))
        sys.exit(1)

    # Get available partition(s)
    try:
        partition_list = check_output(
            'lsblk -p -l -o NAME,SIZE,FSTYPE,TYPE,MOUNTPOINT,MODEL | \
grep part | sed "s/part //g"', shell=True).decode('utf-8').split('\n')
        partition_list = list(filter(None, partition_list))
    except CalledProcessError:
        partition_list = None

    # Get Processor
    try:
        cpu = check_output('cat /proc/cpuinfo | grep "model name" | uniq',
                           shell=True).decode('utf-8').split('\n')
        cpu = cpu[0].split(': ')[-1]
        cpu = re.sub(' +', ' ', cpu)
    except CalledProcessError:
        logging.error(trad('unreconized CPU !'))
        sys.exit(1)

    # Get available VGA controller(s)
    try:
        gpu_list = check_output('lspci | grep -e VGA -e 3D | sed "s/.*: //g" \
| sed "s/Graphics Controller //g"', shell=True).decode('utf-8').split('\n')
        gpu_list = list(filter(None, gpu_list))
    except CalledProcessError:
        gpu_list = None

    # Get NTFS partition(s)
    try:
        ntfs = check_output('lsblk -f | grep ntfs', shell=True)
        ntfs = True
    except CalledProcessError:
        ntfs = False

    # Get LVM partition(s)
    try:
        lvm = check_output('lsblk | grep lvm', shell=True)
        lvm = True
    except CalledProcessError:
        lvm = False

    # Get LUKS partition(s)
    try:
        luks = check_output('lsblk | grep crypt', shell=True)
        luks = True
    except CalledProcessError:
        luks = False

    # Get IP adress data
    try:
        ipinfo = get('https://ipinfo.io?token=26d03faada92e8').json()
    except ConnectionError:
        logging.error(trad('cannot connect to ipinfo.io !'))
        sys.exit(1)

    # Get mirrors for user country
    url = 'https://www.archlinux.org/mirrorlist/?country=\
{country}&use_mirror_status=on'.format(country=ipinfo['country'])
    try:
        mirrors = check_output('curl -s {url}'.format(url=quote(url)),
                               shell=True).decode('utf-8')
        mirrors = mirrors.replace('#Server =', 'Server =')
    except CalledProcessError:
        mirrors = None

    # Get firmware
    if os.path.isdir('/sys/firmware/efi/efivars'):
        firmware = 'uefi'
        if '64' in open('/sys/firmware/efi/fw_platform_size').read():
            efi = 'x64'
        else:
            efi = 'x86'
    else:
        firmware = 'bios'
        efi = None

    # Raw string literal to valid partition sizes
    size_regex = r'^[1-9]{1}[0-9]{0,2}(,[0-9]{1,3}){0,1}(M|G|T){1}$'

    return (drive_list, partition_list, cpu, gpu_list, ntfs,
            lvm, luks, ipinfo, mirrors, firmware, efi, size_regex)


""" Validation Functions: ensure valid user answers

    Arguments:
        user {dictionary} -- options selected by the user
        response {string} -- answers

    Raises:
        errors.ValidationError: display a short description for valid entry

    Returns:
        boolean -- True
    ______________________________________________________________________ """


def boot_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 100000000) or \
            (parse_size(response.replace(',', '.')) > 2000000000) or (
                parse_size(response.replace(',', '.')) >
                parse_size(user['drive'].split()[1].replace(',', '.'))):
        raise errors.ValidationError(
            '', reason=trad('Invalid size for BOOT: {response} (e.q., 512M) \
Minimum [100M] Maximum [2G] Remaining [{drive_size}]'.format(
                response=response, drive_size=user['drive'].split()[1])))
    return True


def root_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 5000000000) or \
            (parse_size(response.replace(',', '.')) > 16000000000000) or \
            (parse_size(response.replace(',', '.')) > (
                int(parse_size(user['drive'].split()[1].replace(',', '.'))) -
                int(parse_size(user['boot_size'].replace(',', '.'))))):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for ROOT: {response} (e.q., 25G) Minimum [5G] \
Maximum [16T] Remaining [{available}]'.format(
                response=response, available=format_size(int(
                    parse_size(user['drive'].split()[1].replace(',', '.'))) -
                    int(parse_size(user['boot_size'].replace(',', '.')))))))
    return True


def swap_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 1000000000) or \
            (parse_size(response.replace(',', '.')) > 32000000000) or \
            (parse_size(response.replace(',', '.')) > (
                int(parse_size(user['drive'].split()[1].replace(',', '.'))) -
                int(parse_size(user['boot_size'].replace(',', '.'))) -
                update_root_size(user))):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for SWAP: {response} (e.q., 2G) Minimum [1G] \
Maximum [32G] Remaining [{available}]'.format(
                response=response, available=format_size(int(
                    parse_size(user['drive'].split()[1].replace(',', '.'))) -
                    int(parse_size(user['boot_size'].replace(',', '.'))) -
                    update_root_size(user)))))
    return True


def home_size_validation(user, response):
    if (not re.match(size_regex, response)) or \
            (parse_size(response.replace(',', '.')) < 4000000000) or \
            (parse_size(response.replace(',', '.')) > 16000000000000) or \
            (parse_size(response.replace(',', '.')) > (
                int(parse_size(user['drive'].split()[1].replace(',', '.'))) -
                int(parse_size(user['boot_size'].replace(',', '.'))) -
                int(parse_size(user['root_size'].replace(',', '.'))) -
                update_swap_size(user))):
        raise errors.ValidationError('', reason=trad(
            'Invalid size for HOME: {response} (e.q., 100G) Minimum [4G] \
Maximum [16T] Remaining [{available}]'.format(
                response=response, available=format_size(
                    int(parse_size(
                        user['drive'].split()[1].replace(',', '.'))) -
                    int(parse_size(user['boot_size'].replace(',', '.'))) -
                    int(parse_size(user['root_size'].replace(',', '.'))) -
                    update_swap_size(user)))))
    return True


def timezone_validation(user, response):
    timezone_list = open(
        '{path}/libraries/timezone'.format(path=os.getcwd())).read()
    if ('{response}\n'.format(response=response) not in timezone_list) or \
            (response == ''):
        raise errors.ValidationError('', reason=trad(
            'Invalid timezone: {response} (e.q., Europe/Paris)'
            .format(response=response)))
    return True


def language_validation(user, response):
    language_list = open(
        '{path}/libraries/language'.format(path=os.getcwd())).read()
    if ('{response}\n'.format(response=response) not in language_list) or \
            (response == ''):
        raise errors.ValidationError('', reason=trad(
            'Invalid language code: {response} (e.q., fr_FR)'
            .format(response=response)))
    return True


def hostname_validation(user, response):
    if not re.match(r'^[a-zA-Z0-9][-a-zA-Z0-9_]{1,31}$', response):
        raise errors.ValidationError('', reason=trad(
            'Invalid hostname: {response} (e.q., my-computer)'
            .format(response=response)))
    return True


def passwd_validation(user, response):
    if not re.match(r'^(?=.*[A-Za-z])(?=.*\d)[\S]{8,}$', response):
        raise errors.ValidationError('', reason=trad(
            'Password should be at least 8 chars long with \
one letter and one digit !'))
    return True


def username_validation(user, response):
    if not re.match(r'^[a-z_]{1}[a-z0-9_-]{1,31}$', response):
        raise errors.ValidationError('', reason=trad(
            'Invalid username: {response} (e.q., JohnDoe)'
            .format(response=response)))
    return True


""" Ignore Functions: bypass conditions for questions

    Arguments:
        user {dictionary} -- options selected by the user

    Returns:
        boolean -- True
    ______________________________________________________________________ """


def ignore_lvm(user):
    if (user['drive'] is None) or (firmware == 'bios'):
        return True


def ignore_luks(user):
    if user['lvm'] is False:
        return True


def ignore_boot_size(user):
    if user['drive'] is None:
        return True


def ignore_root_freespace(user):
    if (user['drive'] is None) or ('Home' in user['optional_partitions']):
        return True


def ignore_root_size(user):
    if (user['drive'] is None) or (user['root_freespace'] is True):
        return True


def ignore_swap_size(user):
    if (user['drive'] is None) or ('Swap' not in user['optional_partitions']):
        return True


def ignore_home_freespace(user):
    if (user['drive'] is None) or ('Home' not in user['optional_partitions']):
        return True


def ignore_home_size(user):
    if (user['drive'] is None) or \
            ('Home' not in user['optional_partitions']) or \
            (user['home_freespace'] is True):
        return True


def ignore_required_partition_id(user):
    if user['drive'] is not None:
        return True
    elif partition_list is None:
        logging.error(trad('no partition detected !'))
        sys.exit(1)


def ignore_swap_id(user):
    if (user['drive'] is not None) or \
            ('Swap' not in user['optional_partitions']):
        return True


def ignore_home_id(user):
    if (user['drive'] is not None) or \
            ('Home' not in user['optional_partitions']):
        return True


def ignore_timezone(user):
    if user['timezone'] is not None:
        return True


def ignore_desktop_extra(user):
    if (user['desktop'] is None) or \
            (user['desktop'] not in [0, 1, 2, 3, 4]):
        return True


def ignore_display_manager(user):
    if user['desktop'] is None:
        return True


def ignore_lightdm_greeter(user):
    if (user['desktop'] is None) or (user['desktop'] == 2) or \
            (user['display'] != 1):
        return True


def ignore_gpu_driver(user):
    if (user['desktop'] is None) or (gpu_list == ['']) or (gpu_list is None):
        return True


def ignore_vga_controller(user):
    if user['gpu_driver'] is False:
        return True


def ignore_nvidia_proprietary(user):
    if (user['gpu_driver'] is False) or \
            ('nvidia' not in user['vga_controller']):
        return True


""" Update Functions
    ______________________________________________________________________ """


def update_partition_list(user):
    """ Deletion of partitions selected by the user,
        to display an updated array after selection.

        Arguments:
            user {dictionary} -- options selected by the user

        Returns:
            partition_list {array} -- available partitions
    """
    if user['boot_id'] in partition_list:
        partition_list.remove(user['boot_id'])

    if 'root_id' in user:
        if user['root_id'] in partition_list:
            partition_list.remove(user['root_id'])

    if 'swap_id' in user:
        if user['swap_id'] in partition_list:
            partition_list.remove(user['swap_id'])

    return partition_list


def update_root_size(user):
    """Assign integer if root size uses freespace
       Required to calculate remaining disk space.

    Arguments:
        user {dictionary} -- options selected by the user

    Returns:
        user['root_size'] {integer} -- zero or partition size in bytes
    """
    if user['root_size'] is None:
        user['root_size'] = '0'
    return int(parse_size(user['root_size']))


def update_swap_size(user):
    """Assign integer if no swap partition
       Required to calculate remaining disk space.

    Arguments:
        user {dictionary} -- options selected by the user

    Returns:
        user['swap_size'] {integer} -- zero or partition size in bytes
    """
    if user['swap_size'] is None:
        user['swap_size'] = '0'
    return int(parse_size(user['swap_size']))


def update_desktop_extra(user):
    """Assign the extra packages name of the selected desktop

    Arguments:
        user {dictionary} -- options selected by the user

    Returns:
        desktop_choice {string} -- question for desktop environment extra
    """
    choice = ['Gnome extra', 'KDE applications', 'Deepin extra',
              'Mate extra', 'XFCE goodies']
    desktop_choice = trad('Do you wish to install {extra}').format(
        extra=choice[user['desktop']])
    return desktop_choice


""" Python Inquirer

    Load system settings.
    Create an array of questions.

    Inquirer should ease the process of asking end user questions,
    parsing, validating answers, managing hierarchical prompts
    and providing error feedback.

    https://magmax.org/python-inquirer/index.html
    ______________________________________________________________________ """
(drive_list, partition_list, cpu, gpu_list, ntfs, lvm, luks, ipinfo, mirrors,
 firmware, efi, size_regex) = system_settings()

questions = [
    inquirer.List(                              # DRIVE
        'drive',
        message=trad('Select the drive to use'),
        choices=drive_list,
        carousel=True),
    inquirer.Confirm(                           # LVM
        'lvm',
        message=trad('Do you wish use Logical Volume Manager (LVM)'),
        ignore=ignore_lvm),
    inquirer.Confirm(                           # LUKS
        'luks',
        message=trad('Do you wish to encrypt the drive (LVM on LUKS)'),
        ignore=ignore_luks),
    inquirer.Checkbox(                          # OPTIONAL PARTITIONS
        'optional_partitions',
        message=trad('Select optional partitions'),
        choices=['Swap', 'Home'],
        default=None),
    inquirer.Text(                              # BOOT SIZE
        'boot_size',
        message=trad('Enter desired size for boot partition'),
        validate=boot_size_validation,
        ignore=ignore_boot_size,),
    inquirer.Confirm(                           # ROOT FREE SPACE
        'root_freespace',
        message=trad('Do you wish use free space for root partition'),
        ignore=ignore_root_freespace),
    inquirer.Text(                              # ROOT SIZE
        'root_size',
        message=trad('Enter desired size for root partition'),
        default=None,
        validate=root_size_validation,
        ignore=ignore_root_size),
    inquirer.Text(                              # SWAP SIZE
        'swap_size',
        message=trad('Enter desired size for swap partition'),
        default=None,
        validate=swap_size_validation,
        ignore=ignore_swap_size),
    inquirer.Confirm(                           # HOME FREE SPACE
        'home_freespace',
        message=trad('Do you wish use free space for home partition'),
        ignore=ignore_home_freespace),
    inquirer.Text(                              # HOME SIZE
        'home_size',
        message=trad('Enter desired size for home partition'),
        validate=home_size_validation,
        ignore=ignore_home_size),
    inquirer.List(                              # BOOT DRIVE ID
        'boot_id',
        message=trad('Select boot partition'),
        choices=partition_list,
        carousel=True,
        ignore=ignore_required_partition_id),
    inquirer.List(                              # ROOT DRIVE ID
        'root_id',
        message=trad('Select root partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_required_partition_id),
    inquirer.List(                              # SWAP DRIVE ID
        'swap_id',
        message=trad('Select swap partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_swap_id),
    inquirer.List(                              # HOME DRIVE ID
        'home_id',
        message=trad('Select home partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_home_id),
    inquirer.List(                              # SELECT TIMEZONE
        'timezone',
        message=trad('Select timezone'),
        choices=[ipinfo['timezone'], (trad('Custom timezone'), None)],
        default=ipinfo['timezone'],
        carousel=True),
    inquirer.Text(                              # ENTER TIMEZONE
        'timezone',
        message=trad('Enter desired timezone'),
        validate=timezone_validation,
        ignore=ignore_timezone),
    inquirer.Text(                              # LANGUAGE
        'language',
        message=trad('Enter language code'),
        validate=language_validation),
    inquirer.Text(                              # HOSTNAME
        'hostname',
        message=trad('Enter hostname'),
        validate=hostname_validation),
    inquirer.Password(                          # ROOT PASSWD
        'root_passwd',
        message=trad('Enter password for root'),
        validate=passwd_validation),
    inquirer.Text(                              # USERNAME
        'username',
        message=trad('Enter username'),
        validate=username_validation),
    inquirer.Password(                          # USER PASSWD
        'user_passwd',
        message=trad('Enter password for user {username}'),
        validate=passwd_validation),
    inquirer.List(                              # LINUX KERNEL
        'kernel',
        message=trad('Select Linux Kernel'),
        choices=[('Linux Default', 0), ('Linux Hardened', 1),
                 ('Linux LTS', 2), ('Linux ZEN', 3)],
        carousel=True),
    inquirer.Confirm(                           # LINUX FIRMWARE
        'firmware',
        message=trad('Do you wish to install Linux Firmware'),
        default=True),
    inquirer.List(                              # DESKTOP ENVIRONMENT
        'desktop',
        message=trad('Select Desktop Environment'),
        choices=[None, ('Gnome', 0), ('KDE', 1), ('Deepin', 2), ('Mate', 3),
                 ('XFCE', 4), ('LXQT', 5), ('LXDE', 6), ('Cinnamon', 7),
                 ('Budgie', 8), ('Enlightenment', 9), ('Awesome', 10),
                 ('Xmonad', 11), ('i3', 12)],
        carousel=True),
    inquirer.Confirm(                           # DESKTOP EXTRAS
        'desktop_extra',
        message=update_desktop_extra,
        ignore=ignore_desktop_extra),
    inquirer.List(                              # DISPLAY MANAGER
        'display',
        message=trad('Select Display Manager'),
        choices=[('Gdm', 0), ('LightDM', 1), ('Sddm', 2),
                 ('Lxdm', 3), ('Xdm', 4)],
        carousel=True,
        ignore=ignore_display_manager),
    inquirer.List(                              # LIGHTDM GREETER
        'greeter',
        message=trad('Select LightDM Greeter'),
        choices=[('Gtk', 0), ('Pantheon', 1), ('Deepin', 2),
                 ('Webkit', 3), ('Litarvan', 4)],
        carousel=True,
        ignore=ignore_lightdm_greeter),
    inquirer.Confirm(                           # GPU DRIVER
        'gpu_driver',
        message=trad('Do you wish to install GPU driver'),
        ignore=ignore_gpu_driver),
    inquirer.List(                              # SELECT GPU
        'vga_controller',
        message=trad('Select GPU Controller'),
        choices=gpu_list,
        carousel=True,
        ignore=ignore_vga_controller),
    inquirer.Confirm(                           # HARDWARE VIDEO
        'hardvideo',
        message=trad('Do you wish to install Hardware video acceleration'),
        ignore=ignore_vga_controller),
    inquirer.Confirm(                           # NVIDIA PROPRIETARY
        'gpu_proprietary',
        message=trad('Do you wish to install proprietary drivers'),
        ignore=ignore_nvidia_proprietary),
    inquirer.List(                              # AUR HELPER
        'aur_helper',
        message=trad('Select AUR Helper'),
        choices=[None, 'Yay', 'Pamac-aur', 'Trizen',
                 'Pacaur', 'Pakku', 'Pikaur'],
        carousel=True),
    inquirer.Confirm(                           # USER POWER
        'power',
        message=trad('Do you wish add to all groups user {username}'),
        default=True)
]


""" Dictionary manager

    Update and sort dictionary containing user options.
    Append packages from JSON file (json/packages.json).
    Delete unused entries when values are stored.

    Returns:
        user {dictionary} -- options selected by the user
    ______________________________________________________________________ """


def dictionary_manager():

    """ Append DRIVE
        __________________________________________________________________ """

    # Custom mode
    if user['drive'] is not None:

        # Append drive
        user['drive'] = {'name': user['drive'].split()[0],
                         'size': user['drive'].split()[1],
                         'model': user['drive'].split()[2],
                         'boot': user['drive'].split()[0],
                         'lvm': user['lvm'],
                         'luks': user['luks']}

        # Append LVM packages
        if user['lvm'] is True:
            user['drive']['lvm'] = packages['lvm']

        # Append partition table
        if firmware == 'uefi':
            user['drive']['table'] = 'gpt'
        else:
            user['drive']['table'] = 'mbr'

    # Custom mode
    else:

        # Get boot drive
        boot = str(drive_list[0]).split()[0]
        for drive in drive_list:
            if str(drive).split()[0] in user['boot_id'].split()[0]:
                boot = str(drive).split()[0]
                break

        # Append drive
        user['drive'] = {'name': None, 'boot': boot,
                         'lvm': lvm, 'luks': luks}

        # Append LVM packages
        if lvm is True:
            user['drive']['lvm'] = packages['lvm']

    """ Append PARTITIONS
        __________________________________________________________________ """

    # Default mode
    if user['drive']['name'] is not None:

        # Set root size
        if user['root_freespace'] is True:
            user['root_size'] = 'freespace'

        # Append partitions
        user['partitions'] = {'name': ['boot', 'root'],
                              'size': [user['boot_size'], user['root_size']],
                              'filesystem': ['fat32', 'ext4'],
                              'mountpoint': ['/mnt/boot', '/mnt']}

        # Append swap
        if 'Swap' in user['optional_partitions']:
            user['partitions']['name'].insert(1, 'swap')
            user['partitions']['size'].insert(1, user['swap_size'])
            user['partitions']['filesystem'].insert(1, 'swap')
            user['partitions']['mountpoint'].insert(1, 'swap')

        # Append home
        if 'Home' in user['optional_partitions']:
            user['partitions']['name'].append('home')
            if user['home_freespace'] is True:
                user['home_size'] = 'freespace'
            user['partitions']['size'].append(user['home_size'])
            user['partitions']['filesystem'].append('ext4')
            user['partitions']['mountpoint'].append('/mnt/home')

    # Custom mode
    else:

        # Append partitions
        user['partitions'] = {'name': ['boot', 'root'],
                              'drive_id': [user['boot_id'].split()[0],
                                           user['root_id'].split()[0]],
                              'mountpoint': ['/mnt/boot', '/mnt']}

        # Append swap
        if user['swap_id'] is not None:
            user['partitions']['name'].insert(1, 'swap')
            user['partitions']['drive_id'].insert(1,
                                                  user['swap_id'].split()[0])
            user['partitions']['mountpoint'].insert(1, 'swap')

        # Append home
        if user['home_id'] is not None:
            user['partitions']['name'].append('home')
            user['partitions']['drive_id'].append(user['home_id'].split()[0])
            user['partitions']['mountpoint'].append('/mnt/home')

    """ Append KERNEL
        __________________________________________________________________ """
    user['kernel'] = packages['kernel'][user['kernel']]

    """ Append PROCESSOR
        __________________________________________________________________ """
    if 'intel' in cpu.lower():
        user['cpu'] = {'name': cpu, 'microcode': packages['microcode'][0]}
    elif 'AMD' in cpu:
        user['cpu'] = {'name': cpu, 'microcode': packages['microcode'][1]}
    else:
        user['cpu'] = {'name': cpu, 'microcode': None}

    """ Append GPU CONTROLLER
        __________________________________________________________________ """
    if user['gpu_driver'] is True:

        # NVIDIA controller
        if 'nvidia' in user['vga_controller'].lower():
            if user['gpu_proprietary'] is True:
                hardvideo = packages['hardvideo'][3]
                if user['kernel'] == 'linux':
                    gpu_driver = packages['gpu_driver'][3]
                elif user['kernel'] == 'linux-lts':
                    gpu_driver = packages['gpu_driver'][4]
                else:
                    gpu_driver = packages['gpu_driver'][5]
            else:
                gpu_driver = packages['gpu_driver'][2]
                hardvideo = packages['hardvideo'][2]

        # AMD Controller
        elif ('ATI' in user['vga_controller']) or \
                ('AMD' in user['vga_controller']):
            gpu_driver = packages['gpu_driver'][1]
            hardvideo = packages['hardvideo'][1]

        # Intel controller
        elif 'intel' in user['vga_controller'].lower():
            gpu_driver = packages['gpu_driver'][0]
            hardvideo = packages['hardvideo'][0]

        # Unreconized controller
        else:
            gpu_driver = packages['gpu_driver'][6]
    else:
        gpu_driver = None

    # Append GPU
    user['gpu'] = {'model': user['vga_controller'],
                   'driver': gpu_driver,
                   'hardvideo': user['hardvideo']}

    # Append hardware video acceleration
    if user['hardvideo'] is True:
        user['gpu']['hardvideo'] = hardvideo

    """ Append NTFS SUPPORT
        __________________________________________________________________ """
    user['ntfs'] = ntfs
    if ntfs is True:
        user['ntfs'] = packages['ntfs']

    """ Append DESKTOP ENVIRONMENT
        __________________________________________________________________ """
    user['desktop_environment'] = {'name': user['desktop']}
    if user['desktop'] is not None:
        if user['desktop'] in [10, 11, 12]:
            user['desktop_environment']['requirements'] = \
                '{xorg} {xinit} {numlock}'.format(xorg=packages['xorg'],
                                                  xinit=packages['xinit'],
                                                  numlock=packages['numlock'])
        else:
            user['desktop_environment']['requirements'] = \
                '{xinit} {numlock}'.format(xinit=packages['xorg'],
                                           numlock=packages['numlock'])
        user['desktop_environment']['name'] = \
            packages['desktop']['name'][user['desktop']]
        user['desktop_environment']['packages'] = \
            packages['desktop']['packages'][user['desktop']]
        if user['desktop_extra'] is True:
            user['desktop_environment']['packages'] = \
                '{packages} {extras}'.format(
                    packages=user['desktop_environment']['packages'],
                    extras=packages['desktop']['extras'][user['desktop']])
        user['desktop_environment']['startcmd'] = \
            packages['desktop']['startcmd'][user['desktop']]

    """ Append DISPLAY MANAGER
        __________________________________________________________________ """
    user['display_manager'] = {'name': user['display']}
    if user['display'] is not None:
        user['display_manager']['name'] = \
            packages['display_manager']['name'][user['display']]
        user['display_manager']['packages'] = \
            packages['display_manager']['packages'][user['display']]
        if user['greeter'] is not None:
            user['display_manager']['packages'] = \
                '{packages} {greeter}'.format(
                    packages=user['display_manager']['packages'],
                    greeter=packages['greeter']['packages'][user['greeter']])
            user['display_manager']['session'] = \
                packages['greeter']['session'][user['greeter']]

    """ Append PASSWORDS
        __________________________________________________________________ """
    rootpasswd = crypt(user['root_passwd'], mksalt(METHOD_SHA512))
    userpasswd = crypt(user['root_passwd'], mksalt(METHOD_SHA512))
    user['passwords'] = {'root': rootpasswd, 'user': userpasswd}

    """ Append KEYMAP
        __________________________________________________________________ """
    if 'keymap' not in locals():
        user['keymap'] = user['language'].split('_')[0]

    """ Append FIRMWARE
        __________________________________________________________________ """
    user['firmware'] = {'type': firmware, 'version': efi,
                        'driver': user['firmware']}
    if user['firmware']['driver'] is True:
        user['firmware']['driver'] = packages['firmware']

    """ Append IP
        __________________________________________________________________ """
    user['ip'] = ipinfo['ip']

    """ Append MIRRORLIST
        __________________________________________________________________ """
    user['mirrorlist'] = mirrors

    """ Delete unused entries
        __________________________________________________________________ """
    unused_entries = ['root_freespace', 'home_freespace', 'hardvideo',
                      'optional_partitions', 'boot_id', 'greeter', 'display',
                      'boot_size', 'root_size', 'swap_size', 'home_size',
                      'root_id', 'lvm', 'swap_id', 'home_id', 'luks',
                      'user_passwd', 'root_passwd', 'desktop', 'gpu_driver',
                      'vga_controller', 'gpu_proprietary', 'desktop_extra']
    for unused in unused_entries:
        del user[unused]

    """ Return dictionary
        __________________________________________________________________ """
    return user


""" Start Manager

    Call the prompt render.
    Update user dictionary.
    Prompt installation confirmation.
    Call again the prompt render on negative.
    Otherwise store dictionary as JSON file in temp folder.
    ______________________________________________________________________ """

while True:
    user = inquirer.prompt(questions, theme=load_theme_from_dict(theme))
    dictionary_manager()
    logging.warning(trad('this action cannot be canceled !'))
    confirm = inquirer.confirm(trad('Do you wish to install Arch Linux now'))
    if confirm is True:
        break

with open('{path}/json/settings.json'.format(path=os.getcwd()), 'w',
          encoding='utf-8') as settings:
    json.dump(user, settings, ensure_ascii=False, indent=4)


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
