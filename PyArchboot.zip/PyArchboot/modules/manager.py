# -*- coding: utf-8 -*-

"""Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import gettext
import json
import logging
import os
import re
import sys
from crypt import METHOD_SHA512, crypt, mksalt
from shlex import quote
from subprocess import CalledProcessError, check_output

import inquirer
from humanfriendly import format_size, parse_size
from inquirer import errors
from inquirer.themes import load_theme_from_dict


# Load app settings
with open('{path}/json/app.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as app_settings:
    app = json.load(app_settings)


# Load archlinux packages
with open('{path}/json/packages.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as packages_list:
    packages = json.load(packages_list)


# Load inquirer theme
with open('{path}/json/theme.json'.format(path=os.getcwd()), 'r',
          encoding='utf-8') as inquirer_theme:
    theme = json.load(inquirer_theme)


# Load app language
language = gettext.translation('PyArchboot', localedir='locales',
                               languages=['{lang}'.format(lang=app['lang'])])
trad = language.gettext


# System settings - get hardware configuration.
##############################################################################


def command_output(cmd):
    """Get the output of an UNIX command.

    Arguments:
        cmd {string} -- quoted UNIX command
    """
    try:
        output = check_output(cmd, shell=True, encoding='utf-8')

    except CalledProcessError:
        output = False

    return output


def system_settings():
    """Use command_output function to get the required system settings.

    Returns:
        drive_list     {array} -- available drives
        partition_list {array} -- available partitions
        cpu           {string} -- CPU model
        gpu_list       {array} -- available VGA Controllers
        ntfs         {boolean} -- NTFS support (check for ntfs partitions)
        lvm          {boolean} -- LVM support (check for LVM partitions)
        luks         {boolean} -- LUKS support (check for encrypted volumes)
        mirrors       {string} -- user country mirrors
        firmware      {string} -- system firmware (bios or uefi)
        efi           {string} -- uefi firmware type (x86 or x64)
    """
    # Get available drive(s)
    cmd = 'lsblk -I 8 -d -p -o NAME,SIZE,MODEL | grep -v NAME'
    drive_list = command_output(cmd)
    if drive_list is not False:
        drive_list = list(filter(None, drive_list.split('\n')))
        drive_list.insert(0, (trad('Use already formatted partitions'), None))
    else:
        logging.error(trad('no drive detected !'))
        sys.exit(1)

    # Get available partition(s)
    cmd = 'lsblk -p -l -o NAME,SIZE,FSTYPE,TYPE,MOUNTPOINT,MODEL | \
grep part | sed "s/part //g"'

    partition_list = command_output(cmd)
    if partition_list is not False:
        partition_list = list(filter(None, partition_list.split('\n')))

    # Get the processor
    cpu = command_output('cat /proc/cpuinfo | grep "model name" | uniq')
    if cpu is not False:
        cpu = cpu.split('\n')[0].split(': ')[-1]
        cpu = re.sub(' +', ' ', cpu)
    else:
        logging.error(trad('unreconized CPU !'))
        sys.exit(1)

    # Get available VGA controller(s)
    cmd = 'lspci | grep -e VGA -e 3D | sed "s/.*: //g" | sed \
"s/Graphics Controller //g"'

    gpu_list = command_output(cmd)
    if gpu_list is not False:
        gpu_list = list(filter(None, gpu_list.split('\n')))

    # Check for NTFS partition(s)
    ntfs = command_output('lsblk -f | grep ntfs')
    if ntfs is not False:
        ntfs = True

    # Check for LVM partition(s)
    lvm = command_output('lsblk | grep lvm')
    if lvm is not False:
        lvm = True

    # Check for LUKS volume(s)
    luks = command_output('lsblk | grep crypt')
    if luks is not False:
        luks = True

    # Get the mirrors of the user country
    url = 'https://www.archlinux.org/mirrorlist/?country={country}&\
use_mirror_status=on'.format(country=app['ipinfo']['country'])

    mirrors = command_output('curl -s {url}'.format(url=quote(url)))
    if mirrors is not False:
        mirrors = mirrors.replace('#Server =', 'Server =')

    # Get system firmware
    if os.path.isdir('/sys/firmware/efi/efivars'):
        firmware = 'uefi'

        if '64' in open('/sys/firmware/efi/fw_platform_size').read():
            efi = 'x64'
        else:
            efi = 'x86'
    else:
        firmware = 'bios'
        efi = None

    # Return required system settings
    return (drive_list, partition_list, cpu, gpu_list, ntfs, lvm, luks,
            mirrors, firmware, efi)


# Validation Functions - ensure valid user answers.
##############################################################################


def size_counter(user):
    """Calculate disk space usage."""
    counter = 0
    size_list = ['boot_size', 'root_size', 'swap_size', 'home_size']

    for size in size_list:
        if (size in user) and (user[size] is not None):
            counter += parse_size(user[size].replace(',', '.'))

    return counter


def index_counter(user):
    """Define partitions index."""
    index = 0
    if 'swap_size' in user:
        index = 3
    elif 'root_size' in user:
        index = 2
    elif 'boot_size' in user:
        index = 1

    return index


def size_validation(user, response):
    """Validate partition sizes."""
    name = ['boot', 'root', 'swap', 'home']
    min_size = ['100M', '5G', '1G', '4G']
    max_size = ['2G', '16T', '32G', '16T']
    eq_size = ['512M', '25G', '2G', '100G']
    valid_size = r'^[1-9]{1}[0-9]{0,2}((,|\.)[0-9]{1,2}){0,1}(M|G|T){1}$'

    if (not re.match(valid_size, response)) \
            or ((size_counter(user) + parse_size(response
                                                 .replace(',', '.'))) >
                parse_size(user['drive'].split()[1].replace(',', '.'))) \
            or (parse_size(response.replace(',', '.')) <
                parse_size(min_size[index_counter(user)])) \
            or (parse_size(response.replace(',', '.')) >
                parse_size(max_size[index_counter(user)])):

        raise errors.ValidationError('', reason='Invalid size for {name}: \
{response} (e.q., {eq}) Minimum [{min}] Maximum [{max}] \
Remaining [{free}]'.format(
            name=name[index_counter(user)],
            response=response, eq=eq_size[index_counter(user)],
            min=min_size[index_counter(user)],
            max=max_size[index_counter(user)],
            free=format_size(
                parse_size(user['drive'].split()[1].replace(',', '.')) -
                size_counter(user))))

    return True


def timezone_validation(user, response):
    """Match timezone code in libraries/timezone."""
    timezone_list = open(
        '{path}/libraries/timezone'.format(path=os.getcwd())).read()

    if ('{response}\n'.format(response=response) not in timezone_list) or \
            (response == ''):

        raise errors.ValidationError('', reason=trad(
            'Invalid timezone: {response} (e.q., Europe/Paris)'.format(
                response=response)))

    return True


def language_validation(user, response):
    """Match language code in libraries/language."""
    language_list = open(
        '{path}/libraries/language'.format(path=os.getcwd())).read()

    if ('{response}\n'.format(response=response) not in language_list) or \
            (response == ''):

        raise errors.ValidationError('', reason=trad(
            'Invalid language code: {response} (e.q., fr_FR)'
            .format(response=response)))

    return True


def hostname_validation(user, response):
    """Regex to match UNIX hostnames."""
    if not re.match(r'^[a-zA-Z0-9][-a-zA-Z0-9_]{1,31}$', response):

        raise errors.ValidationError('', reason=trad(
            'Invalid hostname: {response} (e.q., my-computer)'
            .format(response=response)))

    return True


def passwd_validation(user, response):
    """Regex to match UNIX passwords."""
    if not re.match(r'^(?=.*[A-Za-z])(?=.*\d)[\S]{8,}$', response):

        raise errors.ValidationError('', reason=trad(
            'Password should be at least 8 chars long with \
one letter and one digit !'))

    return True


def username_validation(user, response):
    """Regex to match UNIX usernames."""
    if not re.match(r'^[a-z_]{1}[a-z0-9_-]{1,31}$', response):

        raise errors.ValidationError('', reason=trad(
            'Invalid username: {response} (e.q., JohnDoe)'
            .format(response=response)))

    return True


# Ignore Functions - bypass conditions for some questions.
##############################################################################


def ignore_lvm(user):
    """Ignore LVM support in case of BIOS Firmware."""
    if (user['drive'] is None) or (firmware == 'bios'):
        return True


def ignore_luks(user):
    """Ignore LUKS support in case of BIOS Firmware."""
    if user['lvm'] is False:
        return True


def ignore_boot_size(user):
    """Ignore boot partition size in case of custom partitions mode."""
    if user['drive'] is None:
        return True


def ignore_root_freespace(user):
    """Ignore freespace for root when optional/custom partitions selected."""
    if (user['drive'] is None) or ('Home' in user['optional_partitions']):
        return True


def ignore_root_size(user):
    """Ignore root partition size in case of freespace or custom mode."""
    if (user['drive'] is None) or (user['root_freespace'] is True):
        return True


def ignore_swap_size(user):
    """Ignore swap partition size in case of None or custom mode."""
    if (user['drive'] is None) or ('Swap' not in user['optional_partitions']):
        return True


def ignore_home_freespace(user):
    """Ignore freespace for home in case of None or custom mode."""
    if (user['drive'] is None) or ('Home' not in user['optional_partitions']):
        return True


def ignore_home_size(user):
    """Ignore home partition size in case of None or custom mode."""
    if (user['drive'] is None) or \
            ('Home' not in user['optional_partitions']) or \
            (user['home_freespace'] is True):

        return True


def ignore_required_partition_id(user):
    """Ignore partition selection if dedicated drive or no partition."""
    if user['drive'] is not None:
        return True

    elif partition_list is None:
        logging.error(trad('no partition detected !'))
        sys.exit(1)


def ignore_swap_id(user):
    """Ignore swap partition selection in case of dedicated drive."""
    if (user['drive'] is not None) or \
            ('Swap' not in user['optional_partitions']):

        return True


def ignore_home_id(user):
    """Ignore home partition selection in case of dedicated drive."""
    if (user['drive'] is not None) or \
            ('Home' not in user['optional_partitions']):

        return True


def ignore_timezone(user):
    """Ignore custom timezone in case of detected one selected."""
    if user['timezone'] is not None:
        return True


def ignore_desktop_extra(user):
    """Ignore desktop extras when DE is None or no extra packages."""
    if (user['desktop'] is None) or \
            (user['desktop'] not in [0, 1, 2, 3, 4]):

        return True


def ignore_display_manager(user):
    """Ignore display manager selection in case of DE is None."""
    if user['desktop'] is None:
        return True


def ignore_lightdm_greeter(user):
    """Ignore LightDM greeter when display manager is not LightDM."""
    if (user['desktop'] is None) or (user['display'] != 1):
        return True


def ignore_gpu_driver(user):
    """Ignore GPU driver choice when DE is None or no controller."""
    if (user['desktop'] is None) or (gpu_list == ['']) or (gpu_list is False):
        return True


def ignore_vga_controller(user):
    """Ignore VGA Controller selection in case of GPU driver is False."""
    if user['gpu_driver'] is False:
        return True


def ignore_nvidia_proprietary(user):
    """Ignore proprietary drivers in case of GPU is False or not nVidia."""
    if (user['gpu_driver'] is False) or \
            ('nvidia' not in user['vga_controller']):

        return True


# Update Functions - display updated inquirer messages.
##############################################################################


def update_partition_list(user):
    """Del selected partition to display an updated array after selection.

    Returns:
        partition_list {array} -- remaining partitions
    """
    if user['boot_id'] in partition_list:
        partition_list.remove(user['boot_id'])

    if 'root_id' in user:
        if user['root_id'] in partition_list:
            partition_list.remove(user['root_id'])

    if 'swap_id' in user:
        if user['swap_id'] in partition_list:
            partition_list.remove(user['swap_id'])

    return partition_list


def update_desktop_extra(user):
    """Assign the extra packages name of the selected desktop.

    Returns:
        desktop_choice {string} -- question for desktop environment extra
    """
    choice = ['Gnome extra', 'KDE applications', 'Deepin extra',
              'Mate extra', 'XFCE goodies']

    desktop_choice = trad('Do you wish to install {extra}').format(
        extra=choice[user['desktop']])

    return desktop_choice


"""Python Inquirer.

Get required system settings.
Create an array of questions.

Inquirer should ease the process of asking end user questions,
parsing, validating answers, managing hierarchical prompts
and providing error feedback.

https://magmax.org/python-inquirer/index.html
"""
##############################################################################

(drive_list, partition_list, cpu, gpu_list, ntfs, lvm, luks, mirrors,
 firmware, efi) = system_settings()

questions = [

    # Drive
    inquirer.List(
        'drive',
        message=trad('Select the drive to use'),
        choices=drive_list,
        carousel=True),

    # Lvm
    inquirer.Confirm(
        'lvm',
        message=trad('Do you wish use Logical Volume Manager (LVM)'),
        ignore=ignore_lvm),

    # Luks
    inquirer.Confirm(
        'luks',
        message=trad('Do you wish to encrypt the drive (LVM on LUKS)'),
        ignore=ignore_luks),

    # Optional partitions
    inquirer.Checkbox(
        'optional_partitions',
        message=trad('Select optional partitions'),
        choices=['Swap', 'Home'],
        default=None),

    # Boot size
    inquirer.Text(
        'boot_size',
        message=trad('Enter desired size for boot partition'),
        validate=size_validation,
        ignore=ignore_boot_size),

    # Root freespace
    inquirer.Confirm(
        'root_freespace',
        message=trad('Do you wish use free space for root partition'),
        ignore=ignore_root_freespace),

    # Root size
    inquirer.Text(
        'root_size',
        message=trad('Enter desired size for root partition'),
        default=None,
        validate=size_validation,
        ignore=ignore_root_size),

    # Swap size
    inquirer.Text(
        'swap_size',
        message=trad('Enter desired size for swap partition'),
        default=None,
        validate=size_validation,
        ignore=ignore_swap_size),

    # Home freespace
    inquirer.Confirm(
        'home_freespace',
        message=trad('Do you wish use free space for home partition'),
        ignore=ignore_home_freespace),

    # Home size
    inquirer.Text(
        'home_size',
        message=trad('Enter desired size for home partition'),
        validate=size_validation,
        ignore=ignore_home_size),

    # Boot drive ID
    inquirer.List(
        'boot_id',
        message=trad('Select boot partition'),
        choices=partition_list,
        carousel=True,
        ignore=ignore_required_partition_id),

    # Root drive ID
    inquirer.List(
        'root_id',
        message=trad('Select root partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_required_partition_id),

    # Swap drive ID
    inquirer.List(
        'swap_id',
        message=trad('Select swap partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_swap_id),

    # Home drive ID
    inquirer.List(
        'home_id',
        message=trad('Select home partition'),
        choices=update_partition_list,
        carousel=True,
        ignore=ignore_home_id),

    # Timezone selection
    inquirer.List(
        'timezone',
        message=trad('Select timezone'),
        choices=[app['ipinfo']['timezone'], (trad('Custom timezone'), None)],
        default=app['ipinfo']['timezone'],
        carousel=True),

    # Custom timezone
    inquirer.Text(
        'timezone',
        message=trad('Enter desired timezone'),
        validate=timezone_validation,
        ignore=ignore_timezone),

    # Language code
    inquirer.Text(
        'language',
        message=trad('Enter language code'),
        validate=language_validation),

    # Hostname
    inquirer.Text(
        'hostname',
        message=trad('Enter hostname'),
        validate=hostname_validation),

    # Root passwd
    inquirer.Password(
        'root_passwd',
        message=trad('Enter password for root'),
        validate=passwd_validation),

    # Username
    inquirer.Text(
        'username',
        message=trad('Enter username'),
        validate=username_validation),

    # User passwd
    inquirer.Password(
        'user_passwd',
        message=trad('Enter password for user {username}'),
        validate=passwd_validation),

    # Kernel
    inquirer.List(
        'kernel',
        message=trad('Select Linux Kernel'),
        choices=[('Linux Stable', 0), ('Linux Hardened', 1),
                 ('Linux LTS', 2), ('Linux ZEN', 3)],
        carousel=True),

    # Firmware drivers
    inquirer.Confirm(
        'firmware',
        message=trad('Do you wish to install Linux Firmware'),
        default=True),

    # Desktop environment
    inquirer.List(
        'desktop',
        message=trad('Select Desktop Environment'),
        choices=[None, ('Gnome', 0), ('KDE', 1), ('Deepin', 2), ('Mate', 3),
                 ('XFCE', 4), ('LXQT', 5), ('LXDE', 6), ('Cinnamon', 7),
                 ('Budgie', 8), ('Enlightenment', 9), ('Awesome', 10),
                 ('Xmonad', 11), ('i3', 12)],
        carousel=True),

    # Desktop extras
    inquirer.Confirm(
        'desktop_extra',
        message=update_desktop_extra,
        ignore=ignore_desktop_extra),

    # Display manager
    inquirer.List(
        'display',
        message=trad('Select Display Manager'),
        choices=[('Gdm', 0), ('LightDM', 1), ('Sddm', 2),
                 ('Lxdm', 3), ('Xdm', 4)],
        carousel=True,
        ignore=ignore_display_manager),

    # LightDM greeter
    inquirer.List(
        'greeter',
        message=trad('Select LightDM Greeter'),
        choices=[('Gtk', 0), ('Pantheon', 1), ('Deepin', 2),
                 ('Webkit', 3), ('Litarvan', 4)],
        carousel=True,
        ignore=ignore_lightdm_greeter),

    # GPU Driver
    inquirer.Confirm(
        'gpu_driver',
        message=trad('Do you wish to install GPU driver'),
        ignore=ignore_gpu_driver),

    # VGA Controller selection
    inquirer.List(
        'vga_controller',
        message=trad('Select GPU Controller'),
        choices=gpu_list,
        carousel=True,
        ignore=ignore_vga_controller),

    # Hardware video acceleration
    inquirer.Confirm(
        'hardvideo',
        message=trad('Do you wish to install Hardware video acceleration'),
        ignore=ignore_vga_controller),

    # nVidia proprietary drivers
    inquirer.Confirm(
        'gpu_proprietary',
        message=trad('Do you wish to install proprietary drivers'),
        ignore=ignore_nvidia_proprietary),

    # AUR Helper
    inquirer.List(
        'aur_helper',
        message=trad('Select AUR Helper'),
        choices=[None, 'Yay', 'Pamac-aur', 'Trizen',
                 'Pacaur', 'Pakku', 'Pikaur'],
        carousel=True),

    # User groups
    inquirer.Confirm(
        'power',
        message=trad('Do you wish add to all groups user {username}'),
        default=True)
]


# Dictionary manager - append user options with the corresponding packages.
##############################################################################


def dictionary_manager():
    """Update and sort the dictionary containing user options.

    Append packages from JSON file (json/packages.json).
    Delete unused entries when values are stored.

    Returns:
        user {dictionary} -- options selected by the user
    """
    # Append the disk :
    ###################

    # Default mode (dedicated drive)
    if user['drive'] is not None:

        # Append drive
        user['drive'] = {'name': user['drive'].split()[0],
                         'size': user['drive'].split()[1],
                         'model': user['drive'].split()[2],
                         'boot': user['drive'].split()[0],
                         'lvm': user['lvm'], 'luks': user['luks']}

        # Append LVM packages
        if user['lvm'] is True:
            user['drive']['lvm'] = packages['lvm']

        # Append partition table
        if firmware == 'uefi':
            user['drive']['table'] = 'gpt'

        else:
            user['drive']['table'] = 'mbr'

    # Custom mode (custom partitions)
    else:

        # Get boot drive
        boot = str(drive_list[0]).split()[0]
        for drive in drive_list:
            if str(drive).split()[0] in user['boot_id'].split()[0]:
                boot = str(drive).split()[0]
                break

        # Append drive
        user['drive'] = {'name': None, 'boot': boot, 'lvm': lvm, 'luks': luks}

        # Append LVM packages
        if lvm is True:
            user['drive']['lvm'] = packages['lvm']

    # Append the PARTITIONS :
    #########################

    # Default mode (dedicated drive)
    if user['drive']['name'] is not None:

        # Set root size
        if user['root_freespace'] is True:
            user['root_size'] = 'freespace'

        # Append partitions
        user['partitions'] = {'name': ['boot', 'root'],
                              'size': [user['boot_size'], user['root_size']],
                              'filesystem': ['fat32', 'ext4'],
                              'mountpoint': ['/mnt/boot', '/mnt'],
                              'mountorder': [1, 0]}

        # Append swap
        if 'Swap' in user['optional_partitions']:
            user['partitions']['name'].insert(1, 'swap')
            user['partitions']['size'].insert(1, user['swap_size'])
            user['partitions']['filesystem'].insert(1, 'swap')
            user['partitions']['mountpoint'].insert(1, 'swap')
            user['partitions']['mountorder'].insert(1, 2)

        # Append home
        if 'Home' in user['optional_partitions']:
            user['partitions']['name'].append('home')
            if user['home_freespace'] is True:
                user['home_size'] = 'freespace'
            user['partitions']['size'].append(user['home_size'])
            user['partitions']['filesystem'].append('ext4')
            user['partitions']['mountpoint'].append('/mnt/home')
            user['partitions']['mountorder'].append(3)

    # Custom mode (custom partitions)
    else:

        # Append partitions
        user['partitions'] = {'name': ['boot', 'root'],
                              'drive_id': [user['boot_id'].split()[0],
                                           user['root_id'].split()[0]],
                              'mountpoint': ['/mnt/boot', '/mnt'],
                              'mountorder': [1, 0]}

        # Append swap
        if user['swap_id'] is not None:
            user['partitions']['name'].insert(1, 'swap')
            user['partitions']['drive_id'].insert(1,
                                                  user['swap_id'].split()[0])
            user['partitions']['mountpoint'].insert(1, 'swap')
            user['partitions']['mountorder'].insert(1, 2)

        # Append home
        if user['home_id'] is not None:
            user['partitions']['name'].append('home')
            user['partitions']['drive_id'].append(user['home_id'].split()[0])
            user['partitions']['mountpoint'].append('/mnt/home')
            user['partitions']['mountorder'].append(3)

    # Append the KERNEL :
    #####################
    user['kernel'] = packages['kernel'][user['kernel']]

    # Append the PROCESSOR :
    ########################
    if 'intel' in cpu.lower():
        user['cpu'] = {'name': cpu, 'microcode': packages['microcode'][0]}

    elif 'AMD' in cpu:
        user['cpu'] = {'name': cpu, 'microcode': packages['microcode'][1]}

    else:
        user['cpu'] = {'name': cpu, 'microcode': None}

    # Append the VGA CONTROLLER :
    #############################
    if user['gpu_driver'] is True:

        # NVIDIA controller
        if 'nvidia' in user['vga_controller'].lower():

            if user['gpu_proprietary'] is True:
                hardvideo = packages['hardvideo'][3]

                if user['kernel'] == 'linux':
                    gpu_driver = packages['gpu_driver'][3]

                elif user['kernel'] == 'linux-lts':
                    gpu_driver = packages['gpu_driver'][4]

                else:
                    gpu_driver = packages['gpu_driver'][5]

            else:
                gpu_driver = packages['gpu_driver'][2]
                hardvideo = packages['hardvideo'][2]

        # AMD Controller
        elif ('ATI' in user['vga_controller']) or \
                ('AMD' in user['vga_controller']):

            gpu_driver = packages['gpu_driver'][1]
            hardvideo = packages['hardvideo'][1]

        # Intel controller
        elif 'intel' in user['vga_controller'].lower():
            gpu_driver = packages['gpu_driver'][0]
            hardvideo = packages['hardvideo'][0]

        # Unreconized controller
        else:
            gpu_driver = packages['gpu_driver'][6]
            hardvideo = packages['hardvideo'][4]
    else:
        gpu_driver = None

    # Append model with corresponding driver
    user['gpu'] = {'model': user['vga_controller'],
                   'driver': gpu_driver,
                   'hardvideo': user['hardvideo']}

    # Append hardware video acceleration
    if user['hardvideo'] is True:
        user['gpu']['hardvideo'] = hardvideo

    # Append NTFS SUPPORT :
    #######################
    user['ntfs'] = ntfs
    if ntfs is True:
        user['ntfs'] = packages['ntfs']

    # Append the DESKTOP ENVIRONMENT :
    ##################################
    user['desktop_environment'] = {'name': user['desktop']}
    if user['desktop'] is not None:

        if user['desktop'] in [10, 11, 12]:
            user['desktop_environment']['requirements'] = \
                '{xorg} {xinit} {numlock}'.format(xorg=packages['xorg'],
                                                  xinit=packages['xinit'],
                                                  numlock=packages['numlock'])
        else:
            user['desktop_environment']['requirements'] = \
                '{xinit} {numlock}'.format(xinit=packages['xorg'],
                                           numlock=packages['numlock'])

        user['desktop_environment']['name'] = \
            packages['desktop']['name'][user['desktop']]

        user['desktop_environment']['packages'] = \
            packages['desktop']['packages'][user['desktop']]

        if user['desktop_extra'] is True:
            user['desktop_environment']['packages'] += ' {extras}'.format(
                extras=packages['desktop']['extras'][user['desktop']])

        user['desktop_environment']['startcmd'] = \
            packages['desktop']['startcmd'][user['desktop']]

    # Append the DISPLAY MANAGER :
    ##############################
    user['display_manager'] = {'name': user['display']}

    if user['display'] is not None:
        user['display_manager']['name'] = \
            packages['display_manager']['name'][user['display']]

        user['display_manager']['packages'] = \
            packages['display_manager']['packages'][user['display']]

        if user['greeter'] is not None:
            user['display_manager']['packages'] += ' {greeter}'.format(
                greeter=packages['greeter']['packages'][user['greeter']])

            user['display_manager']['session'] = \
                packages['greeter']['session'][user['greeter']]

    # Append the PASSWORDS :
    ########################
    rootpasswd = crypt(user['root_passwd'], mksalt(METHOD_SHA512))
    userpasswd = crypt(user['user_passwd'], mksalt(METHOD_SHA512))
    user['passwords'] = {'root': rootpasswd, 'user': userpasswd}

    # Append the KEYMAP :
    #####################
    if 'keymap' not in locals():
        user['keymap'] = user['language'].split('_')[0]

    # Append sytem FIRMWARE :
    #########################
    user['firmware'] = {'type': firmware, 'version': efi,
                        'driver': user['firmware']}

    if user['firmware']['driver'] is True:
        user['firmware']['driver'] = packages['firmware']

    # Append user MIRRORLIST :
    ##########################
    user['mirrorlist'] = mirrors

    # Delete unused entries :
    #########################
    unused_entries = ['root_freespace', 'home_freespace', 'hardvideo',
                      'optional_partitions', 'boot_id', 'greeter', 'display',
                      'boot_size', 'root_size', 'swap_size', 'home_size',
                      'root_id', 'lvm', 'swap_id', 'home_id', 'luks',
                      'user_passwd', 'root_passwd', 'desktop', 'gpu_driver',
                      'vga_controller', 'gpu_proprietary', 'desktop_extra']

    for unused in unused_entries:
        del user[unused]

    # Return updated dictionary :
    #############################
    return user


"""Start the manager.

Call the prompt render.
Update user dictionary.
Prompt installation confirmation.
Call again the prompt render on negative.
Otherwise store dictionary as JSON file.
"""
##############################################################################
while True:
    user = inquirer.prompt(questions, theme=load_theme_from_dict(theme))
    dictionary_manager()

    logging.warning(trad('this action cannot be canceled !'))

    question = [inquirer.Confirm(
        'install', message=trad('Do you wish to install Arch Linux now'),
        default=True)]

    confirm = inquirer.prompt(question, theme=load_theme_from_dict(theme))
    if confirm['install'] is True:
        break

with open('{path}/json/settings.json'.format(path=os.getcwd()), 'w',
          encoding='utf-8') as settings:
    json.dump(user, settings, ensure_ascii=False, indent=4)


# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
##############################################################################
