# -*- coding: utf-8 -*-

"""
    Copyright 2020 Jeremy Pardo @grm34 https://github.com/grm34

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
"""

base = {
    'arch': 'base',
    'kernel': ['linux', 'linux-hardened', 'linux-lts', 'linux-zen'],
    'firmware': 'linux-firmware',
    'microcode': ['intel_ucode', 'amd-ucode'],
    'devel': 'base-devel',
    'lvm': 'lvm2',
    'sudo': 'sudo',
    'grub': ['grub2', 'os-prober'],
    'ntfs': 'ntfs-3g',
    'network': [
        'networkmanager',
        'net-tools dhcpcd iw wpa_supplicant wireless_tools wget git'
    ]
}

desktop = {
    'gnome': '',
    'kde': '',
    'mate': '',
    'xfce': '',
    'deepin': '',
    'lxqt': '',
    'cinnamon': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': '',
    '': ''


}
test = {'ok': '',
        '','
         '}

# PyArchboot - Python Arch Linux Installer by grm34 under Apache License 2.0
# ============================================================================
