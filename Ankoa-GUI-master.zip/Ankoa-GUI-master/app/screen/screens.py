#!/usr/bin/kivy
from kivy.uix.screenmanager import Screen


class AnkoaScreen(Screen):
    pass
