![](http://i.imgur.com/Lx2SfgZ.png) Ankoa-GUI [![Code Health](https://landscape.io/github/Ankoa/Ankoa-GUI/master/landscape.svg?style=flat)](https://landscape.io/github/Ankoa/Ankoa-GUI/master) [![maintenance](https://img.shields.io/maintenance/yes/2015.svg)](https://github.com/Ankoa/Ankoa-GUI)
=========

**Open Source Video Tools - Python GUI multi plateform**

Encode or remux your favorites videos from local to server
![](http://i.imgur.com/5m9EGNs.png)
![](http://i.imgur.com/d8eEEGv.png)
![](http://i.imgur.com/3J4dB03.png)
![](http://i.imgur.com/8CZFo7L.png)
![](http://i.imgur.com/E26zA5t.png)
![](http://i.imgur.com/7fwAmSV.png)
![](http://i.imgur.com/sZoqw0V.png)
![](http://i.imgur.com/u3SIplI.png)
![](http://i.imgur.com/PviQdsO.png)
![](http://i.imgur.com/htpmQnE.png)
![](http://i.imgur.com/kOCPgdc.png)
![](http://i.imgur.com/K70z8W1.png)
![](http://i.imgur.com/nFJgm33.png)
