---
name: 'Question'
about: 'Ask a question about archboot'
title: ''
labels: '☎️ question'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->
