---
name: 'Bug report'
about: 'Create a report to help archboot improve'
title: ''
labels: '⚠️ potential bug'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->
