---
name: 'Feature request'
about: 'Suggest an idea for archboot'
title: ''
labels: '🙏 feature request'
assignees: ''
---

<!-- Please search existing issues to avoid creating duplicates. -->

<!-- Describe the feature you'd like. -->
