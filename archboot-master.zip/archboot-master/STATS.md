Language|files|blank|comment|code
:-------|-------:|-------:|-------:|-------:
Bourne Again Shell|15|357|486|1100
Markdown|2|24|0|72
Bourne Shell|1|8|8|24
--------|--------|--------|--------|--------
SUM:|18|389|494|1196

File|blank|comment|code
:-------|-------:|-------:|-------:
archboot|79|121|288
src/arch/user|45|55|178
src/arch/partitioning|53|67|164
src/arch/base|26|34|79
src/arch/display|15|29|68
src/arch/gpu_driver|20|22|60
src/arch/bootloader|17|23|53
src/arch/mirrorlist|15|21|46
src/arch/firmware|13|13|46
README.md|23|0|43
src/arch/desktop|12|20|39
STATS.md|1|0|29
src/conf/xinitrc|8|8|24
src/apps/desktop_apps|20|24|24
src/apps/system_apps|11|13|16
src/apps/gpu_apps|14|19|16
src/arch/mounting|9|15|13
src/apps/display_apps|8|10|10
--------|--------|--------|--------
SUM:|389|494|1196
